I. Instructions for configuration  

1. Copy the CyDIW_Root to a folder of your choice. 

2. Edit SystemConfig.xml 

A. For client systems you do not intend to use, set Enabled="no". 

B. For client systems you intend to use, edit corresponding ClassPath or LibraryPath.

3. (You can skip this step if you only intend to use SQL, Quilt or independent XQuery engines.) 

A. Decide the size of the storage in Megabytes, where to place the storage for CyDIW storage. 

B. The corresponding folders must be created manually. 

C. Edit StorageConfig.xml file to reflect the path and size of the storage. 


II. To start CyDIW, run startCyDIW.bat in Windows or startcydiw.sh in Linux. 

III. The list of CyDB commands.

$CyDB:> list commands;
$CyDB:> list variables;
$CyDB:> clear variables;
$CyDB:> clear logs;
$CyDB:> declare <int/string/int[]/string[] Type> <Variable> [:= <AssigningValues>];
$CyDB:> undeclare <int/string/int[]/string[] Type> <Variable>;
$CyDB:> set <Variable> := <AssigningValues>;
$CyDB:> execute <Variable> [log <custom/time> >> <RootTag> <XMLFileName>];
$CyDB:> foreach <Variable> in (<ExpressionsList>) [log <custom/time> >> <RootTag> <XMLFileName>] { <CommandsList> }
$CyDB:> createlog <RootTag> <XMLFileName>;
$CyDB:> displayfile <XML/TXT FileName>;
$CyDB:> createRawStorage <StorageConfigXMLFile>;
$CyDB:> useStorage <StorageConfigXMLFile>;
$CyDB:> formatStorage <PageSize>;
$CyDB:> startBufferManager <BufferPoolSize>;
$CyDB:> showdirectory;
$CyDB:> createfile <XML/BXML/CXML FileName> <FileSize>;
$CyDB:> copyfile <XML/BXML/CXML FileName> <XML/BXML/CXML FileName>;
$CyDB:> deletefile <XML/BXML/CXML FileName>;
$CyDB:> writeBitMap;
$CyDB:> getPageAllocatedCount;
$CyDB:> getPageDeallocatedCount;
$CyDB:> getPageRequestCount;
$CyDB:> getPageAccessCount;
$CyDB:> getPageAccessRelativeCount;
$CyDB:> resetPageAccessRelativeCount;
