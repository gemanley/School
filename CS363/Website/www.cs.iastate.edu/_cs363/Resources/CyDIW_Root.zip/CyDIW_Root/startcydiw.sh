#!/bin/sh
cd `dirname $0`
 
java \
	-Xms128m -Xmx512m \
	-classpath `java edu.iastate.cs.cydiw.SystemConfigClasspath < SystemConfig.xml` \
	diwGUI.gui.DBGui
