package edu.iastate.cs.cydiw;

/*
 * Section A. Import libraries
 */

import java.io.IOException;

import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;

import edu.iastate.cs.cydiw.StorageManagerClient;
import edu.iastate.cs.cydiw.canstorex.dom.DOMNode;

public class JDBCX_Client {

	
	public static void processOutput(DOMNode root) throws IOException{
		
        	Node entry = root.getFirstChild() ;

		while(entry!=null)
        {
        	
        	if(entry.getLocalName().equalsIgnoreCase("E1"))
            {
            	String p = entry.getFirstChild().getNodeValue();
            		 	
            	System.out.println(p);
            }	
        	entry = entry.getNextSibling();
        }	
				
	}
	
	public static void main(String[] args) throws Exception{
		 
		/*
	     * Section B. Create and initialize an instance of Client
	     * and create a storageManagerClient associated with this client.
	     * smc is initialized with 4 buffers in this demo, but you can change it.
	     * And start a connection to server.
	     */
	    
			String hostname = "localhost";	       
			int port = 4360;
			Client myClient = new Client(hostname, port);
			StorageManagerClient mySMC = new StorageManagerClient(4,myClient);
			myClient.startConnection();
			/*
	         * Section C.1. Client composes a query  and sends to server
	         * and get the query output file name
	         */
	        String qry ="let $auction:=doc(\"auctions(1).bxml\") for $b in $auction/people/person return <E1>{$b/name/text()}</E1>";
	        String resultFileName =myClient.execute(myClient, qry);
	       
	        /*
	         * Section C.2. Client starts to load and process the output file
	         * 
	         */
	       
	        DOMNode myRoot = myClient.loadFile(mySMC, resultFileName);
	        processOutput(myRoot);
	
	        /*
	         * Section D Release the buffer pool and close the connection
	         * 
	         */
	        mySMC.close();
	        myClient.close();
	}
}