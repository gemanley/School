package edu.iastate.cs.cydiw;

/*
 * Section A. Import libraries
 */
import java.io.File;

import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;

import storagemanager.StorageConfig;
import storagemanager.StorageManagerClient;
import xacute.common.NodeFactory;
import xacute.impl.csx.NodeFactoryCSX;
import xacute.impl.csx.NodeImpl;

import canstorex.util.CanStoreXUtil;

public class CsxDom_StandAlone_Demo {

	
	private static CanStoreXUtil cu;
	
	public static void main(String[] args) throws Exception{
		
		/*
		 * Section B. Initialize the storage and buffer pool
		 */
		File storageConfigFile = new File("P4_StorageConfig.xml");
		cu = new CanStoreXUtil();
		cu.useStorage(new StorageConfig(storageConfigFile));
		cu.startBufferManager(10);
		
		long time = System.currentTimeMillis();
		/*
		 * Section C. Create the root node of a bxml file.
		 * The Demo runs on server side.
		 * If the program runs on client side, you can get root pageId by calling getRootId(Client, FileName),
		 * and initialize process by calling initializeToProcess(smc, rootId)
		 *
		 */
		
		 NodeFactory csxnf = new NodeFactoryCSX(cu);   
         String bxmlFile = "auctions(1).bxml";
         Node root = ((NodeImpl) csxnf.getDocumentRoot(bxmlFile)).getDOMNode();
        
    		/*
    		 * Section D. Start from the people node, which is the root of person tree
    		 */
          Element people = (Element)root.getChildNodes().item(3);
            /*
             * Section D.1. we can start with the first person node 
             * and call getNextSibling() to iterate the person tree
             */
          Element person = (Element)people.getFirstChild();
           
           while(person !=null)
           {
        	   Node name = person.getChildNodes().item(1);
        	   if (name !=null)
        		   System.out.println(name.getFirstChild().getNodeValue().trim());
   			   person = (Element) person.getNextSibling();
           }
           System.out.println();
           System.out.println("Time taken: "+(System.currentTimeMillis()-time));
           /*
            * Section D.2 or we can go through the person tree by calling the index
            */
           /*NodeList personList = people.getChildNodes();
           for(int i=0;i<personList.getLength();i++)
   		   {
   			Element p = (Element)personList.item(i);
   			Node name = p.getChildNodes().item(1);
   				if(name!=null)
   					System.out.println(name.getFirstChild().getNodeValue().trim());
   			
   		   }
    					*/
            
       

}
}