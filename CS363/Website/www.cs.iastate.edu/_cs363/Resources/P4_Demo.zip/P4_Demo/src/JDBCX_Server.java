package edu.iastate.cs.cydiw;

import java.io.*;
import java.net.*;

import storagemanager.StorageConfig;
import storagemanager.StorageManagerClient;
import canstorex.util.CanStoreXUtil;

public class JDBCX_Server {

	   
	    private static StorageManagerClient smc;
		private static CanStoreXUtil cu;
		
	    
	    
	    public static void main(String argv[]) throws UnknownHostException {
	    	
	    	java.net.InetAddress addr = java.net.InetAddress.getLocalHost();
		System.out.println("HostName: "+addr.getHostName() );
		//System.out.println("IP :"+addr.getAddress().toString());
			
	    	
	    	String storageConfigFile = "../CyDIW_bin/P4_StorageConfig.xml";
	    	File storageConfig = new File(storageConfigFile);
    		cu = new CanStoreXUtil();
    		//cu.createStorage(new StorageConfig(storageConfig), false);
    		
    		cu.useStorage(new StorageConfig(storageConfig));
    		
    		cu.startBufferManager(4);
	    	smc = cu.getXmlClient();
	    	int port = 4360;
	    	System.out.println("Port number "+port);
	    	System.out.println("Done");
	        

	        Server server = null;
	        try {
	            server = new Server(port);
	        }
	        catch (IOException e){
	            e.printStackTrace(System.err);
	        }
	        System.out.println("server is now running ...");
	        server.waitForConnections(cu);
	      
	    }
}

