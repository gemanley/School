*****************************
1. Server program should be started before you run clientquery program, and keep it running.
You can modify some prameters in the server program, i.e., buffer number, port number. 

*****************************
2. Clientquery basically sends a query to server, server execute it, and returns the name of the result file to the client.
Client could start processing the resultset by sending the result file name. Client could process any existing file on the server provided its name is known.

*****************************
3. DOM_Demo & CsxDOM_Demo 
