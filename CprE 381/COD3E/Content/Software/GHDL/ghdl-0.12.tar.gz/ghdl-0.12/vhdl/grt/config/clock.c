#include <time.h>

int
grt_get_clk_tck (void)
{
  return CLOCKS_PER_SEC;
}

void
grt_get_times (int *wall, int *user, int *sys)
{
  clock_t res;

  *wall = clock ();
  *user = 0;
  *sys = 0;
}

