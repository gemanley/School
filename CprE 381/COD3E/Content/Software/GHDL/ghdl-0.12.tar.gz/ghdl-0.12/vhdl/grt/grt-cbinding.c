#include <stdio.h>
#include <stdlib.h>

FILE *
__ghdl_get_stdout (void)
{
  return stdout;
}

FILE *
__ghdl_get_stdin (void)
{
  return stdin;
}

FILE *
__ghdl_get_stderr (void)
{
  return stderr;
}

void
__gnat_last_chance_handler (void)
{
  abort ();
}

void *
__gnat_malloc (size_t size)
{
  return malloc (size);
}

void
__gnat_free (void *ptr)
{
  free (ptr);
}

void *
__gnat_realloc (void *ptr, size_t size)
{
  return realloc (ptr, size);
}
