/* Electric on Mac OS/X inside ProjectBuilder */
#define PROJECTBUILDER      1

#if 0		/* at Sun, add in other details */
#  define FORCELISP         1
#  define FORCEJAVA         1
#  define FORCECADENCE      1
#  define FORCESUNTOOLS     1
#  define FORCEIRSIMTOOL    1
#endif
