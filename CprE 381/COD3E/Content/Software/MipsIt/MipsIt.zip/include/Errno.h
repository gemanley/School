#ifndef __ERRNO_H__
#define __ERRNO_H__
#define EDOM	128
#define ERANGE	32767

extern int errno;
#endif /* __ERRNO_H__ */

