#ifdef HAVE_CVS_IDENT
#ident "$Id: vvp_vpi.cc,v 1.8 2003/01/10 19:01:38 steve Exp $"
#endif

#include <stdarg.h>
#include "vpi_user.h"


void vvp_vpi_init()
{
}

/*
 * $Log: vvp_vpi.cc,v $
 * Revision 1.8  2003/01/10 19:01:38  steve
 *  Remove thunks from vpi init.
 *
 */
