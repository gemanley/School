# 1 "../config.h"
# 1 "../auto-config.h" 1
 
 
 
#define HAVE_INTTYPES_H 1

 
 

 
 

 
 

 
 

 
 

 
 

 
 

 
 

 
#define STDC_HEADERS 1

 
#define SYS_SIGLIST_DECLARED 1

 
#define TIME_WITH_SYS_TIME 1

 
#define HAVE_BCMP 1

 
#define HAVE_BCOPY 1

 
#define HAVE_BZERO 1

 
#define HAVE_GETRLIMIT 1

 
#define HAVE_INDEX 1

 
#define HAVE_KILL 1

 
#define HAVE_POPEN 1

 
#define HAVE_PUTENV 1

 
#define HAVE_RINDEX 1

 
#define HAVE_SETRLIMIT 1

 
#define HAVE_STRERROR 1

 
#define HAVE_SYSCONF 1

 
#define HAVE_VPRINTF 1

 
#define HAVE_FCNTL_H 1

 
#define HAVE_LIMITS_H 1

 
#define HAVE_STDDEF_H 1

 
#define HAVE_STDLIB_H 1

 
#define HAVE_STRING_H 1

 
#define HAVE_STRINGS_H 1

 
#define HAVE_SYS_FILE_H 1

 
#define HAVE_SYS_PARAM_H 1

 
#define HAVE_SYS_RESOURCE_H 1

 
#define HAVE_SYS_TIME_H 1

 
#define HAVE_SYS_TIMES_H 1

 
#define HAVE_TIME_H 1

 
#define HAVE_UNISTD_H 1
# 1 "../config.h" 2

# 1 "../config/i386/xm-linux.h" 1
 




















# 1 "../config/i386/xm-i386.h" 1
 























 
#define FALSE 0
#define TRUE 1

 
#define HOST_BITS_PER_CHAR 8
#define HOST_BITS_PER_SHORT 16
#define HOST_BITS_PER_INT 32
#define HOST_BITS_PER_LONG 32
#define HOST_BITS_PER_LONGLONG 64

 
#define SUCCESS_EXIT_CODE 0
#define FATAL_EXIT_CODE 33

 


# 1 "../tm.h" 1
#define TARGET_CPU_DEFAULT 3
# 1 "../config/i386/linux.h" 1
 





















#define LINUX_DEFAULT_ELF

 


# 1 "../config/i386/i386.h" 1
 




















 














 

#define I386 1

 


#define HALF_PIC_P() 0
#define HALF_PIC_NUMBER_PTRS 0
#define HALF_PIC_NUMBER_REFS 0
#define HALF_PIC_ENCODE(DECL)
#define HALF_PIC_DECLARE(NAME)
#define HALF_PIC_INIT()	error ("half-pic init called on systems that don't support it.")
#define HALF_PIC_ADDRESS_P(X) 0
#define HALF_PIC_PTR(X) X
#define HALF_PIC_FINISH(STREAM)


 

struct processor_costs {
  int add;			 
  int lea;			 
  int shift_var;		 
  int shift_const;		 
  int mult_init;		 
  int mult_bit;			 
  int divide;			 
};

extern struct processor_costs *ix86_cost;

 

extern int target_flags;

 

 




 
#define MASK_80387		000000000001	
#define MASK_NOTUSED1		000000000002	
#define MASK_NOTUSED2		000000000004	
#define MASK_RTD		000000000010	
#define MASK_ALIGN_DOUBLE	000000000020	
#define MASK_SVR3_SHLIB		000000000040	
#define MASK_IEEE_FP		000000000100	
#define MASK_FLOAT_RETURNS	000000000200	
#define MASK_NO_FANCY_MATH_387	000000000400	
#define MASK_OMIT_LEAF_FRAME_POINTER 0x00000800 
						 
#define MASK_DEBUG_ADDR		000001000000	
#define MASK_NO_WIDE_MULTIPLY	000002000000	
#define MASK_NO_MOVE		000004000000	
#define MASK_NO_PSEUDO		000010000000	
#define MASK_DEBUG_ARG		000020000000	   
#define MASK_SCHEDULE_PROLOGUE  000040000000    
#define MASK_STACK_PROBE	000100000000	

 
#define TARGET_80387 (target_flags & MASK_80387)

 

  
#define TARGET_RTD (target_flags & MASK_RTD)

 


#define TARGET_ALIGN_DOUBLE (target_flags & MASK_ALIGN_DOUBLE)

 

#define TARGET_SVR3_SHLIB (target_flags & MASK_SVR3_SHLIB)

 


#define TARGET_IEEE_FP (target_flags & MASK_IEEE_FP)

 


#define TARGET_FLOAT_RETURNS_IN_80387 (target_flags & MASK_FLOAT_RETURNS)

 

#define TARGET_NO_FANCY_MATH_387 (target_flags & MASK_NO_FANCY_MATH_387)

 
#define TARGET_OMIT_LEAF_FRAME_POINTER (target_flags & MASK_OMIT_LEAF_FRAME_POINTER)

 

 

#define TARGET_NO_WIDE_MULTIPLY (target_flags & MASK_NO_WIDE_MULTIPLY)
#define TARGET_WIDE_MULTIPLY (!TARGET_NO_WIDE_MULTIPLY)

 
#define TARGET_SCHEDULE_PROLOGUE (target_flags & MASK_SCHEDULE_PROLOGUE)

 
#define TARGET_DEBUG_ADDR (target_flags & MASK_DEBUG_ADDR)

 
#define TARGET_DEBUG_ARG (target_flags & MASK_DEBUG_ARG)

 
#define TARGET_MOVE	((target_flags & MASK_NO_MOVE) == 0)	
#define TARGET_PSEUDO	((target_flags & MASK_NO_PSEUDO) == 0)	

#define TARGET_386 (ix86_cpu == PROCESSOR_I386)
#define TARGET_486 (ix86_cpu == PROCESSOR_I486)
#define TARGET_PENTIUM (ix86_cpu == PROCESSOR_PENTIUM)
#define TARGET_PENTIUMPRO (ix86_cpu == PROCESSOR_PENTIUMPRO)
#define TARGET_USE_LEAVE (ix86_cpu == PROCESSOR_I386)
#define TARGET_PUSH_MEMORY (ix86_cpu == PROCESSOR_I386)
#define TARGET_ZERO_EXTEND_WITH_AND (ix86_cpu != PROCESSOR_I386 && ix86_cpu != PROCESSOR_PENTIUMPRO)

#define TARGET_DOUBLE_WITH_ADD (ix86_cpu != PROCESSOR_I386)
#define TARGET_USE_BIT_TEST (ix86_cpu == PROCESSOR_I386)
#define TARGET_UNROLL_STRLEN (ix86_cpu != PROCESSOR_I386)
#define TARGET_USE_Q_REG (ix86_cpu == PROCESSOR_PENTIUM || ix86_cpu == PROCESSOR_PENTIUMPRO)

#define TARGET_USE_ANY_REG (ix86_cpu == PROCESSOR_I486)
#define TARGET_CMOVE (ix86_arch == PROCESSOR_PENTIUMPRO)
#define TARGET_DEEP_BRANCH_PREDICTION (ix86_cpu == PROCESSOR_PENTIUMPRO)
#define TARGET_STACK_PROBE (target_flags & MASK_STACK_PROBE)

#define TARGET_SWITCHES	{ { "80387",			 MASK_80387 },	{ "no-80387",			-MASK_80387 },	{ "hard-float",		 MASK_80387 },	{ "soft-float",		-MASK_80387 },	{ "no-soft-float",		 MASK_80387 },	{ "386",			 0 },	{ "no-386",			 0 },	{ "486",			 0 },	{ "no-486",			 0 },	{ "pentium",			 0 },	{ "pentiumpro",		 0 },	{ "rtd",			 MASK_RTD },	{ "no-rtd",			-MASK_RTD },	{ "align-double",		 MASK_ALIGN_DOUBLE },	{ "no-align-double",		-MASK_ALIGN_DOUBLE },	{ "svr3-shlib",		 MASK_SVR3_SHLIB },	{ "no-svr3-shlib",		-MASK_SVR3_SHLIB },	{ "ieee-fp",			 MASK_IEEE_FP },	{ "no-ieee-fp",		-MASK_IEEE_FP },	{ "fp-ret-in-387",		 MASK_FLOAT_RETURNS },	{ "no-fp-ret-in-387",		-MASK_FLOAT_RETURNS },	{ "no-fancy-math-387",	 MASK_NO_FANCY_MATH_387 },	{ "fancy-math-387",		-MASK_NO_FANCY_MATH_387 },	{ "omit-leaf-frame-pointer",	 MASK_OMIT_LEAF_FRAME_POINTER }, { "no-omit-leaf-frame-pointer",-MASK_OMIT_LEAF_FRAME_POINTER }, { "no-wide-multiply",		 MASK_NO_WIDE_MULTIPLY },	{ "wide-multiply",		-MASK_NO_WIDE_MULTIPLY },	{ "schedule-prologue",	 MASK_SCHEDULE_PROLOGUE },	{ "no-schedule-prologue",	-MASK_SCHEDULE_PROLOGUE },	{ "debug-addr",		 MASK_DEBUG_ADDR },	{ "no-debug-addr",		-MASK_DEBUG_ADDR },	{ "move",			-MASK_NO_MOVE },	{ "no-move",			 MASK_NO_MOVE },	{ "debug-arg",		 MASK_DEBUG_ARG },	{ "no-debug-arg",		-MASK_DEBUG_ARG },	{ "stack-arg-probe",		 MASK_STACK_PROBE },	{ "no-stack-arg-probe",	-MASK_STACK_PROBE },	{ "windows",			0 },	{ "dll",			0 },	SUBTARGET_SWITCHES	{ "", MASK_SCHEDULE_PROLOGUE | TARGET_DEFAULT}}
# 214 "../config/i386/i386.h"

 


enum processor_type
 {PROCESSOR_I386,			 
  PROCESSOR_I486,			 
  PROCESSOR_PENTIUM,
  PROCESSOR_PENTIUMPRO};

#define PROCESSOR_I386_STRING "i386"
#define PROCESSOR_I486_STRING "i486"
#define PROCESSOR_I586_STRING "i586"
#define PROCESSOR_PENTIUM_STRING "pentium"
#define PROCESSOR_I686_STRING "i686"
#define PROCESSOR_PENTIUMPRO_STRING "pentiumpro"

extern enum processor_type ix86_cpu;

extern int ix86_arch;

 
#define PROCESSOR_DEFAULT ((enum processor_type) TARGET_CPU_DEFAULT == PROCESSOR_I486) ? PROCESSOR_I486 : ((enum processor_type) TARGET_CPU_DEFAULT == PROCESSOR_PENTIUM) ? PROCESSOR_PENTIUM : ((enum processor_type) TARGET_CPU_DEFAULT == PROCESSOR_PENTIUMPRO) ? PROCESSOR_PENTIUMPRO : PROCESSOR_I386







#define PROCESSOR_DEFAULT_STRING ((enum processor_type) TARGET_CPU_DEFAULT == PROCESSOR_I486) ? PROCESSOR_I486_STRING : ((enum processor_type) TARGET_CPU_DEFAULT == PROCESSOR_PENTIUM) ? PROCESSOR_PENTIUM_STRING : ((enum processor_type) TARGET_CPU_DEFAULT == PROCESSOR_PENTIUMPRO) ? PROCESSOR_PENTIUMPRO_STRING : PROCESSOR_I386_STRING








 








#define TARGET_OPTIONS	{ { "cpu=",		&ix86_cpu_string},	{ "arch=",		&ix86_arch_string},	{ "reg-alloc=",	&i386_reg_alloc_order },	{ "regparm=",		&i386_regparm_string },	{ "align-loops=",	&i386_align_loops_string },	{ "align-jumps=",	&i386_align_jumps_string },	{ "align-functions=",	&i386_align_funcs_string },	{ "branch-cost=",	&i386_branch_cost_string },	SUBTARGET_OPTIONS	}
# 273 "../config/i386/i386.h"

 








#define OVERRIDE_OPTIONS override_options ()

 
#define SUBTARGET_SWITCHES
#define SUBTARGET_OPTIONS

 
#define OPTIMIZATION_OPTIONS(LEVEL) optimization_options(LEVEL)

 


#define CC1_CPU_SPEC "\
%{!mcpu*: \
%{m386:-mcpu=i386 -march=i386} \
%{mno-486:-mcpu=i386 -march=i386} \
%{m486:-mcpu=i486 -march=i486} \
%{mno-386:-mcpu=i486 -march=i486} \
%{mno-pentium:-mcpu=i486 -march=i486} \
%{mpentium:-mcpu=pentium} \
%{mno-pentiumpro:-mcpu=pentium} \
%{mpentiumpro:-mcpu=pentiumpro}}"
# 305 "../config/i386/i386.h"











#define CPP_CPU_DEFAULT "-Di686"






#define CPP_CPU_SPEC "\
-Di386 " CPP_CPU_DEFAULT " -Asystem(unix) -Acpu(i386) -Amachine(i386) \
%{mcpu=i486:-Di486} %{m486:-Di486} \
%{mpentium:-Dpentium -Di586} %{mcpu=pentium:-Dpentium -Di586} \
%{mpentiumpro:-Dpentiumpro -Di686} %{mcpu=pentiumpro:-Dpentiumpro -Di686}"















#define CC1_SPEC "%(cc1_spec) "


 










#define SUBTARGET_EXTRA_SPECS


#define EXTRA_SPECS	{ "cpp_cpu",	CPP_CPU_SPEC },	{ "cc1_cpu",  CC1_CPU_SPEC },	SUBTARGET_EXTRA_SPECS




 

 

#define LONG_DOUBLE_TYPE_SIZE 96

 


 

 
 

#define BITS_BIG_ENDIAN 0

 
 
#define BYTES_BIG_ENDIAN 0

 

 
#define WORDS_BIG_ENDIAN 0

 
#define BITS_PER_UNIT 8

 



#define BITS_PER_WORD 32

 
#define UNITS_PER_WORD 4

 

#define POINTER_SIZE 32

 
#define PARM_BOUNDARY 32

 
#define STACK_BOUNDARY 32

 


#define FUNCTION_BOUNDARY (1 << (i386_align_funcs + 3))

 

#define EMPTY_FIELD_BOUNDARY 32

 







#define BIGGEST_ALIGNMENT (TARGET_ALIGN_DOUBLE ? 64 : 32)

 
#define ALIGN_DFmode (!TARGET_386)

 

#define STRICT_ALIGNMENT 0

 

 
#define PCC_BITFIELD_TYPE_MATTERS 1

 
#define MAX_CODE_ALIGN	6			

 
#define ASM_OUTPUT_LOOP_ALIGN(FILE) ASM_OUTPUT_ALIGN (FILE, i386_align_loops)

 


#define ASM_OUTPUT_ALIGN_CODE(FILE) ASM_OUTPUT_ALIGN ((FILE), i386_align_jumps)


 

 


#define STACK_REGS
#define IS_STACK_MODE(mode) (mode==DFmode || mode==SFmode || mode==XFmode)

 















#define FIRST_PSEUDO_REGISTER 17

 


#define FIXED_REGISTERS {  0, 0, 0, 0, 0, 0, 0, 1, 0,  0,  0,  0,  0,  0,  0,  0,  1 }



 






#define CALL_USED_REGISTERS {  1, 1, 1, 0, 0, 0, 0, 1, 1,  1,  1,  1,  1,  1,  1,  1,  1 }



 


















#define REG_ALLOC_ORDER {  0, 1, 2, 3, 4, 5, 6, 7, 8,  9, 10, 11, 12, 13, 14, 15, 16 }



 












#define ORDER_REGS_FOR_LOCAL_ALLOC order_regs_for_local_alloc ()

 
#define CONDITIONAL_REGISTER_USAGE	{	if (flag_pic)	{	fixed_regs[PIC_OFFSET_TABLE_REGNUM] = 1;	call_used_regs[PIC_OFFSET_TABLE_REGNUM] = 1;	}	if (! TARGET_80387 && ! TARGET_FLOAT_RETURNS_IN_80387) { int i; HARD_REG_SET x;	COPY_HARD_REG_SET (x, reg_class_contents[(int)FLOAT_REGS]); for (i = 0; i < FIRST_PSEUDO_REGISTER; i++ )	if (TEST_HARD_REG_BIT (x, i)) fixed_regs[i] = call_used_regs[i] = 1; }	}
# 551 "../config/i386/i386.h"

 









#define HARD_REGNO_NREGS(REGNO, MODE) (FP_REGNO_P (REGNO) ? 1 : ((GET_MODE_SIZE (MODE) + UNITS_PER_WORD - 1) / UNITS_PER_WORD))



 




 


#define HARD_REGNO_MODE_OK(REGNO, MODE) ((REGNO) < 2 ? 1	: (REGNO) < 4 ? 1	: FP_REGNO_P (REGNO)	? (((int) GET_MODE_CLASS (MODE) == (int) MODE_FLOAT	|| (int) GET_MODE_CLASS (MODE) == (int) MODE_COMPLEX_FLOAT)	&& GET_MODE_UNIT_SIZE (MODE) <= (LONG_DOUBLE_TYPE_SIZE == 96 ? 12 : 8)) : (int) (MODE) != (int) QImode ? 1	: (reload_in_progress | reload_completed) == 1)
# 583 "../config/i386/i386.h"

 




#define MODES_TIEABLE_P(MODE1, MODE2) ((MODE1) == (MODE2))

 


 

 

 
#define STACK_POINTER_REGNUM 7

 
#define FRAME_POINTER_REGNUM 6

 
#define FIRST_FLOAT_REG 8

 
#define FIRST_STACK_REG FIRST_FLOAT_REG
#define LAST_STACK_REG (FIRST_FLOAT_REG + 7)

 



#define FRAME_POINTER_REQUIRED (TARGET_OMIT_LEAF_FRAME_POINTER && !leaf_function_p ()) 	

 
#define ARG_POINTER_REGNUM 16

 
#define STATIC_CHAIN_REGNUM 2

 

#define PIC_OFFSET_TABLE_REGNUM 3

 


#define STRUCT_VALUE_INCOMING 0

 

#define STRUCT_VALUE 0

 
















#define RETURN_IN_MEMORY(TYPE) ((TYPE_MODE (TYPE) == BLKmode) || int_size_in_bytes (TYPE) > 12)



 























enum reg_class
{
  NO_REGS,
  AREG, DREG, CREG, BREG,
  AD_REGS,			 
  Q_REGS,			 
  SIREG, DIREG,
  INDEX_REGS,			 
  GENERAL_REGS,			 
  FP_TOP_REG, FP_SECOND_REG,	 
  FLOAT_REGS,
  ALL_REGS, LIM_REG_CLASSES
};

#define N_REG_CLASSES (int) LIM_REG_CLASSES

#define FLOAT_CLASS_P(CLASS) (reg_class_subset_p (CLASS, FLOAT_REGS))

 

#define REG_CLASS_NAMES {  "NO_REGS",	"AREG", "DREG", "CREG", "BREG",	"AD_REGS",	"Q_REGS",	"SIREG", "DIREG",	"INDEX_REGS",	"GENERAL_REGS",	"FP_TOP_REG", "FP_SECOND_REG",	"FLOAT_REGS",	"ALL_REGS" }
# 712 "../config/i386/i386.h"

 



#define REG_CLASS_CONTENTS {      0,	0x1,    0x2,  0x4,	 0x8,	0x3,	0xf,	0x10,   0x20,	0x7f,	0x100ff,	0x0100, 0x0200,	0xff00,	0x1ffff }
# 728 "../config/i386/i386.h"

 




#define REGNO_REG_CLASS(REGNO) (regclass_map[REGNO])

 



#define SMALL_REGISTER_CLASSES 1

#define QI_REG_P(X) (REG_P (X) && REGNO (X) < 4)

#define NON_QI_REG_P(X) (REG_P (X) && REGNO (X) >= 4 && REGNO (X) < FIRST_PSEUDO_REGISTER)


#define FP_REG_P(X) (REG_P (X) && FP_REGNO_P (REGNO (X)))
#define FP_REGNO_P(n) ((n) >= FIRST_STACK_REG && (n) <= LAST_STACK_REG)
  
#define STACK_REG_P(xop) (REG_P (xop) &&	REGNO (xop) >= FIRST_STACK_REG &&	REGNO (xop) <= LAST_STACK_REG)



#define NON_STACK_REG_P(xop) (REG_P (xop) && ! STACK_REG_P (xop))

#define STACK_TOP_P(xop) (REG_P (xop) && REGNO (xop) == FIRST_STACK_REG)

 


 

 


 

 

#define INDEX_REG_CLASS INDEX_REGS
#define BASE_REG_CLASS GENERAL_REGS

 

#define REG_CLASS_FROM_LETTER(C)	((C) == 'r' ? GENERAL_REGS :	(C) == 'q' ? Q_REGS :	(C) == 'f' ? (TARGET_80387 || TARGET_FLOAT_RETURNS_IN_80387	? FLOAT_REGS	: NO_REGS) :	(C) == 't' ? (TARGET_80387 || TARGET_FLOAT_RETURNS_IN_80387	? FP_TOP_REG	: NO_REGS) :	(C) == 'u' ? (TARGET_80387 || TARGET_FLOAT_RETURNS_IN_80387	? FP_SECOND_REG	: NO_REGS) :	(C) == 'a' ? AREG :	(C) == 'b' ? BREG :	(C) == 'c' ? CREG :	(C) == 'd' ? DREG :	(C) == 'A' ? AD_REGS :	(C) == 'D' ? DIREG :	(C) == 'S' ? SIREG : NO_REGS)
# 794 "../config/i386/i386.h"

 











#define CONST_OK_FOR_LETTER_P(VALUE, C) ((C) == 'I' ? (VALUE) >= 0 && (VALUE) <= 31 :	(C) == 'J' ? (VALUE) >= 0 && (VALUE) <= 63 :	(C) == 'K' ? (VALUE) == 0xff :	(C) == 'L' ? (VALUE) == 0xffff :	(C) == 'M' ? (VALUE) >= 0 && (VALUE) <= 3 :	(C) == 'N' ? (VALUE) >= 0 && (VALUE) <= 255 : (C) == 'O' ? (VALUE) >= 0 && (VALUE) <= 32 :	0)
# 816 "../config/i386/i386.h"

 




#define CONST_DOUBLE_OK_FOR_LETTER_P(VALUE, C) ((C) == 'G' ? standard_80387_constant_p (VALUE) : 0)


 

#define EXTRA_CONSTRAINT(OP, C) ((C) == 'Q' ? CONSTANT_P (OP) && (! flag_pic || ! SYMBOLIC_CONST (OP)) : 0)


#define EXTRA_CONSTRAINT_NO_S

 



#define LIMIT_RELOAD_CLASS(MODE, CLASS) ((MODE) == QImode && ((CLASS) == ALL_REGS || (CLASS) == GENERAL_REGS) ? Q_REGS : (CLASS))



 







 




#define PREFERRED_RELOAD_CLASS(X,CLASS)	(GET_CODE (X) == CONST_DOUBLE && GET_MODE (X) != VOIDmode ? NO_REGS	: GET_MODE (X) == QImode && ! reg_class_subset_p (CLASS, Q_REGS) ? Q_REGS : ((CLASS) == ALL_REGS	&& GET_MODE_CLASS (GET_MODE (X)) == MODE_FLOAT) ? GENERAL_REGS	: (CLASS))






 


#define SECONDARY_MEMORY_NEEDED(CLASS1,CLASS2,MODE) ((FLOAT_CLASS_P (CLASS1) && ! FLOAT_CLASS_P (CLASS2))	|| (! FLOAT_CLASS_P (CLASS1) && FLOAT_CLASS_P (CLASS2)))



 

 

#define CLASS_MAX_NREGS(CLASS, MODE)	(FLOAT_CLASS_P (CLASS) ? 1 :	((GET_MODE_SIZE (MODE) + UNITS_PER_WORD - 1) / UNITS_PER_WORD))



 















#define CLASS_LIKELY_SPILLED_P(CLASS)	(((CLASS) == AREG)	|| ((CLASS) == DREG)	|| ((CLASS) == CREG)	|| ((CLASS) == BREG)	|| ((CLASS) == AD_REGS)	|| ((CLASS) == SIREG)	|| ((CLASS) == DIREG))









 

 

#define STACK_GROWS_DOWNWARD

 



#define FRAME_GROWS_DOWNWARD

 



#define STARTING_FRAME_OFFSET 0

 





#define PUSH_ROUNDING(BYTES) (((BYTES) + 1) & (-2))

 
#define FIRST_PARM_OFFSET(FNDECL) 0

 
















#define RETURN_POPS_ARGS(FUNDECL,FUNTYPE,SIZE) (i386_return_pops_args (FUNDECL, FUNTYPE, SIZE))


 



#define FUNCTION_VALUE(VALTYPE, FUNC) gen_rtx (REG, TYPE_MODE (VALTYPE), VALUE_REGNO (TYPE_MODE (VALTYPE)))



 


#define LIBCALL_VALUE(MODE) gen_rtx (REG, MODE, VALUE_REGNO (MODE))


 



#define APPLY_RESULT_SIZE (8+108)

 
#define FUNCTION_ARG_REGNO_P(N) ((N) >= 0 && (N) < REGPARM_MAX)

 





typedef struct i386_args {
  int words;			 
  int nregs;			 
  int regno;			 
} CUMULATIVE_ARGS;

 



#define INIT_CUMULATIVE_ARGS(CUM,FNTYPE,LIBNAME,INDIRECT)	(init_cumulative_args (&CUM, FNTYPE, LIBNAME))


 



#define FUNCTION_ARG_ADVANCE(CUM, MODE, TYPE, NAMED)	(function_arg_advance (&CUM, MODE, TYPE, NAMED))


 












#define FUNCTION_ARG(CUM, MODE, TYPE, NAMED) (function_arg (&CUM, MODE, TYPE, NAMED))


 



#define FUNCTION_ARG_PARTIAL_NREGS(CUM, MODE, TYPE, NAMED) (function_arg_partial_nregs (&CUM, MODE, TYPE, NAMED))


 



#undef ASM_OUTPUT_FUNCTION_PREFIX
#define ASM_OUTPUT_FUNCTION_PREFIX(FILE, FNNAME) asm_output_function_prefix (FILE, FNNAME)


 







#define FUNCTION_PROLOGUE(FILE, SIZE) function_prologue (FILE, SIZE)


 


#define FUNCTION_PROFILER(FILE, LABELNO) {	if (flag_pic)	{	fprintf (FILE, "\tleal %sP%d@GOTOFF(%%ebx),%%edx\n",	LPREFIX, (LABELNO));	fprintf (FILE, "\tcall *_mcount@GOT(%%ebx)\n");	}	else	{	fprintf (FILE, "\tmovl $%sP%d,%%edx\n", LPREFIX, (LABELNO));	fprintf (FILE, "\tcall _mcount\n");	}	}
# 1058 "../config/i386/i386.h"


 




























 























































#undef	FUNCTION_BLOCK_PROFILER
#define FUNCTION_BLOCK_PROFILER(FILE, BLOCK_OR_LABEL)	do	{	static int num_func = 0;	rtx xops[8];	char block_table[80], false_label[80];	ASM_GENERATE_INTERNAL_LABEL (block_table, "LPBX", 0);	xops[1] = gen_rtx (SYMBOL_REF, VOIDmode, block_table);	xops[5] = stack_pointer_rtx;	xops[7] = gen_rtx (REG, Pmode, 0);	CONSTANT_POOL_ADDRESS_P (xops[1]) = TRUE;	switch (profile_block_flag) {	case 2:	xops[2] = GEN_INT ((BLOCK_OR_LABEL));	xops[3] = gen_rtx (MEM, Pmode, gen_rtx (SYMBOL_REF, VOIDmode, "__bb_init_trace_func")); xops[6] = GEN_INT (8);	output_asm_insn (AS1(push%L2,%2), xops);	if (!flag_pic)	output_asm_insn (AS1(push%L1,%1), xops);	else	{	output_asm_insn (AS2 (lea%L7,%a1,%7), xops);	output_asm_insn (AS1 (push%L7,%7), xops);	}	output_asm_insn (AS1(call,%P3), xops);	output_asm_insn (AS2(add%L0,%6,%5), xops);	break;	default:	ASM_GENERATE_INTERNAL_LABEL (false_label, "LPBZ", num_func);	xops[0] = const0_rtx;	xops[2] = gen_rtx (MEM, Pmode, gen_rtx (SYMBOL_REF, VOIDmode, false_label)); xops[3] = gen_rtx (MEM, Pmode, gen_rtx (SYMBOL_REF, VOIDmode, "__bb_init_func")); xops[4] = gen_rtx (MEM, Pmode, xops[1]);	xops[6] = GEN_INT (4);	CONSTANT_POOL_ADDRESS_P (xops[2]) = TRUE;	output_asm_insn (AS2(cmp%L4,%0,%4), xops);	output_asm_insn (AS1(jne,%2), xops);	if (!flag_pic)	output_asm_insn (AS1(push%L1,%1), xops);	else	{	output_asm_insn (AS2 (lea%L7,%a1,%7), xops);	output_asm_insn (AS1 (push%L7,%7), xops);	}	output_asm_insn (AS1(call,%P3), xops);	output_asm_insn (AS2(add%L0,%6,%5), xops);	ASM_OUTPUT_INTERNAL_LABEL (FILE, "LPBZ", num_func);	num_func++;	break;	}	}	while (0)
# 1217 "../config/i386/i386.h"

 
































































#define BLOCK_PROFILER(FILE, BLOCKNO)	do	{	rtx xops[8], cnt_rtx;	char counts[80];	char *block_table = counts;	switch (profile_block_flag) {	case 2:	ASM_GENERATE_INTERNAL_LABEL (block_table, "LPBX", 0);	xops[1] = gen_rtx (SYMBOL_REF, VOIDmode, block_table);	xops[2] = GEN_INT ((BLOCKNO));	xops[3] = gen_rtx (MEM, Pmode, gen_rtx (SYMBOL_REF, VOIDmode, "__bb_trace_func")); xops[4] = gen_rtx (SYMBOL_REF, VOIDmode, "__bb");	xops[5] = plus_constant (xops[4], 4);	xops[0] = gen_rtx (MEM, SImode, xops[4]);	xops[6] = gen_rtx (MEM, SImode, xops[5]);	CONSTANT_POOL_ADDRESS_P (xops[1]) = TRUE;	fprintf(FILE, "\tpushf\n");	output_asm_insn (AS2(mov%L0,%2,%0), xops);	if (flag_pic)	{	xops[7] = gen_rtx (REG, Pmode, 0);	output_asm_insn (AS1(push%L7,%7), xops);	output_asm_insn (AS2(lea%L7,%a1,%7), xops);	output_asm_insn (AS2(mov%L6,%7,%6), xops);	output_asm_insn (AS1(pop%L7,%7), xops);	}	else	output_asm_insn (AS2(mov%L6,%1,%6), xops);	output_asm_insn (AS1(call,%P3), xops);	fprintf(FILE, "\tpopf\n");	break;	default:	ASM_GENERATE_INTERNAL_LABEL (counts, "LPBX", 2);	cnt_rtx = gen_rtx (SYMBOL_REF, VOIDmode, counts);	SYMBOL_REF_FLAG (cnt_rtx) = TRUE;	if (BLOCKNO)	cnt_rtx = plus_constant (cnt_rtx, (BLOCKNO)*4);	if (flag_pic)	cnt_rtx = gen_rtx (PLUS, Pmode, pic_offset_table_rtx, cnt_rtx);	xops[0] = gen_rtx (MEM, SImode, cnt_rtx);	output_asm_insn (AS1(inc%L0,%0), xops);	break;	}	}	while (0)
# 1344 "../config/i386/i386.h"

 





















#define FUNCTION_BLOCK_PROFILER_EXIT(FILE) do	{	rtx xops[1];	xops[0] = gen_rtx (MEM, Pmode, gen_rtx (SYMBOL_REF, VOIDmode, "__bb_trace_ret")); output_asm_insn (AS1(call,%P0), xops);	}	while (0)
# 1378 "../config/i386/i386.h"

 




















#define MACHINE_STATE_SAVE(ID) asm ("	pushl %eax"); asm ("	pushl %ecx"); asm ("	pushl %edx"); asm ("	pushl %esi");





#define MACHINE_STATE_RESTORE(ID) asm ("	popl %esi"); asm ("	popl %edx"); asm ("	popl %ecx"); asm ("	popl %eax");





 



 



#define EXIT_IGNORE_STACK 1

 














# 1446 "../config/i386/i386.h"


#define FUNCTION_EPILOGUE(FILE, SIZE) function_epilogue (FILE, SIZE)


 


 



#define TRAMPOLINE_TEMPLATE(FILE)	{	ASM_OUTPUT_CHAR (FILE, GEN_INT (0xb9));	ASM_OUTPUT_SHORT (FILE, const0_rtx);	ASM_OUTPUT_SHORT (FILE, const0_rtx);	ASM_OUTPUT_CHAR (FILE, GEN_INT (0xb8));	ASM_OUTPUT_SHORT (FILE, const0_rtx);	ASM_OUTPUT_SHORT (FILE, const0_rtx);	ASM_OUTPUT_CHAR (FILE, GEN_INT (0xff));	ASM_OUTPUT_CHAR (FILE, GEN_INT (0xe0));	}
# 1469 "../config/i386/i386.h"

 

#define TRAMPOLINE_SIZE 12

 



#define INITIALIZE_TRAMPOLINE(TRAMP, FNADDR, CXT)	{	emit_move_insn (gen_rtx (MEM, SImode, plus_constant (TRAMP, 1)), CXT); emit_move_insn (gen_rtx (MEM, SImode, plus_constant (TRAMP, 6)), FNADDR); }





 











#define ELIMINABLE_REGS	{{ ARG_POINTER_REGNUM, STACK_POINTER_REGNUM},	{ ARG_POINTER_REGNUM, FRAME_POINTER_REGNUM}, { FRAME_POINTER_REGNUM, STACK_POINTER_REGNUM}}




 







#define CAN_ELIMINATE(FROM, TO)	((FROM) == ARG_POINTER_REGNUM && (TO) == STACK_POINTER_REGNUM	? ! frame_pointer_needed	: 1)




 


#define INITIAL_ELIMINATION_OFFSET(FROM, TO, OFFSET)	{	if ((FROM) == ARG_POINTER_REGNUM && (TO) == FRAME_POINTER_REGNUM)	(OFFSET) = 8;	else	{	int regno;	int offset = 0;	for (regno = 0; regno < FIRST_PSEUDO_REGISTER; regno++)	if ((regs_ever_live[regno] && ! call_used_regs[regno])	|| ((current_function_uses_pic_offset_table	|| current_function_uses_const_pool)	&& flag_pic && regno == PIC_OFFSET_TABLE_REGNUM))	offset += 4;	(OFFSET) = offset + get_frame_size ();	if ((FROM) == ARG_POINTER_REGNUM && (TO) == STACK_POINTER_REGNUM)	(OFFSET) += 4;	}	}
# 1539 "../config/i386/i386.h"

 

 
 

 
 

 

 





#define REGNO_OK_FOR_INDEX_P(REGNO) ((REGNO) < STACK_POINTER_REGNUM || (unsigned) reg_renumber[REGNO] < STACK_POINTER_REGNUM)



#define REGNO_OK_FOR_BASE_P(REGNO) ((REGNO) <= STACK_POINTER_REGNUM || (REGNO) == ARG_POINTER_REGNUM || (unsigned) reg_renumber[REGNO] <= STACK_POINTER_REGNUM)




#define REGNO_OK_FOR_SIREG_P(REGNO) ((REGNO) == 4 || reg_renumber[REGNO] == 4)
#define REGNO_OK_FOR_DIREG_P(REGNO) ((REGNO) == 5 || reg_renumber[REGNO] == 5)

 













 
#define REG_OK_FOR_INDEX_NONSTRICT_P(X)	(REGNO (X) < STACK_POINTER_REGNUM	|| REGNO (X) >= FIRST_PSEUDO_REGISTER)



#define REG_OK_FOR_BASE_NONSTRICT_P(X)	(REGNO (X) <= STACK_POINTER_REGNUM	|| REGNO (X) == ARG_POINTER_REGNUM	|| REGNO (X) >= FIRST_PSEUDO_REGISTER)




#define REG_OK_FOR_STRREG_NONSTRICT_P(X)	(REGNO (X) == 4 || REGNO (X) == 5 || REGNO (X) >= FIRST_PSEUDO_REGISTER)


 
#define REG_OK_FOR_INDEX_STRICT_P(X) REGNO_OK_FOR_INDEX_P (REGNO (X))
#define REG_OK_FOR_BASE_STRICT_P(X)  REGNO_OK_FOR_BASE_P (REGNO (X))
#define REG_OK_FOR_STRREG_STRICT_P(X)	(REGNO_OK_FOR_DIREG_P (REGNO (X)) || REGNO_OK_FOR_SIREG_P (REGNO (X)))



#define REG_OK_FOR_INDEX_P(X)  REG_OK_FOR_INDEX_NONSTRICT_P(X)
#define REG_OK_FOR_BASE_P(X)   REG_OK_FOR_BASE_NONSTRICT_P(X)
#define REG_OK_FOR_STRREG_P(X) REG_OK_FOR_STRREG_NONSTRICT_P(X)







 










#define MAX_REGS_PER_ADDRESS 2

#define CONSTANT_ADDRESS_P(X) (GET_CODE (X) == LABEL_REF || GET_CODE (X) == SYMBOL_REF	|| GET_CODE (X) == CONST_INT || GET_CODE (X) == CONST	|| GET_CODE (X) == HIGH)




 


#define LEGITIMATE_CONSTANT_P(X) 1









#define GO_IF_LEGITIMATE_ADDRESS(MODE, X, ADDR)	{	if (legitimate_address_p (MODE, X, 0))	goto ADDR;	}







 




















#define LEGITIMIZE_ADDRESS(X, OLDX, MODE, WIN)	{	rtx orig_x = (X);	(X) = legitimize_address (X, OLDX, MODE);	if (memory_address_p (MODE, X))	goto WIN;	}







#define REWRITE_ADDRESS(x) rewrite_address(x)

 



#define LEGITIMATE_PIC_OPERAND_P(X) (! SYMBOLIC_CONST (X)	|| (GET_CODE (X) == SYMBOL_REF && CONSTANT_POOL_ADDRESS_P (X)))



#define SYMBOLIC_CONST(X)	(GET_CODE (X) == SYMBOL_REF	|| GET_CODE (X) == LABEL_REF	|| (GET_CODE (X) == CONST && symbolic_reference_mentioned_p (X)))




 



#define GO_IF_MODE_DEPENDENT_ADDRESS(ADDR,LABEL)	if (GET_CODE (ADDR) == POST_INC || GET_CODE (ADDR) == POST_DEC) goto LABEL


 






#define ENCODE_SECTION_INFO(DECL) do	{	if (flag_pic)	{	rtx rtl = (TREE_CODE_CLASS (TREE_CODE (DECL)) != 'd'	? TREE_CST_RTL (DECL) : DECL_RTL (DECL));	if (TARGET_DEBUG_ADDR	&& TREE_CODE_CLASS (TREE_CODE (DECL)) == 'd')	{	fprintf (stderr, "Encode %s, public = %s\n",	IDENTIFIER_POINTER (DECL_NAME (DECL)),	TREE_PUBLIC (DECL));	}	SYMBOL_REF_FLAG (XEXP (rtl, 0))	= (TREE_CODE_CLASS (TREE_CODE (DECL)) != 'd'	|| ! TREE_PUBLIC (DECL));	}	}	while (0)
# 1731 "../config/i386/i386.h"

 




#define INIT_EXPANDERS clear_386_stack_locals ()

 






#define FINALIZE_PIC	do	{	extern int current_function_uses_pic_offset_table;	current_function_uses_pic_offset_table |= profile_flag | profile_block_flag; }	while (0)









 



#define VALID_MACHINE_DECL_ATTRIBUTE(DECL, ATTRIBUTES, NAME, ARGS) (i386_valid_decl_attribute_p (DECL, ATTRIBUTES, NAME, ARGS))


 



#define VALID_MACHINE_TYPE_ATTRIBUTE(TYPE, ATTRIBUTES, NAME, ARGS) (i386_valid_type_attribute_p (TYPE, ATTRIBUTES, NAME, ARGS))


 




#define COMP_TYPE_ATTRIBUTES(TYPE1, TYPE2) (i386_comp_type_attributes (TYPE1, TYPE2))


 


 

 




#define REGPARM_MAX 3


 

#define CASE_VECTOR_MODE Pmode

 


 

 


#define IMPLICIT_FIX_EXPR FIX_ROUND_EXPR

 
#define EASY_DIV_EXPR TRUNC_DIV_EXPR

 
#define DEFAULT_SIGNED_CHAR 1

 

#define MOVE_MAX 4

 










#define MOVE_RATIO 5

 


 

 

 

#define TRULY_NOOP_TRUNCATION(OUTPREC, INPREC) 1

 


#define STORE_FLAG_VALUE 1

 


#define PROMOTE_PROTOTYPES

 


#define Pmode SImode

 


#define FUNCTION_MODE QImode

 












#define CONST_COSTS(RTX,CODE,OUTER_CODE) case CONST_INT:	case CONST:	case LABEL_REF:	case SYMBOL_REF:	return flag_pic && SYMBOLIC_CONST (RTX) ? 2 : 1;	case CONST_DOUBLE:	{	int code;	if (GET_MODE (RTX) == VOIDmode)	return 2;	code = standard_80387_constant_p (RTX);	return code == 1 ? 0 :	code == 2 ? 1 :	2;	}
# 1890 "../config/i386/i386.h"

 
#define TOPLEVEL_COSTS_N_INSNS(N) {total = COSTS_N_INSNS (N); break;}

 









#define RTX_COSTS(X,CODE,OUTER_CODE)	case ASHIFT:	if (GET_CODE (XEXP (X, 1)) == CONST_INT	&& GET_MODE (XEXP (X, 0)) == SImode)	{	HOST_WIDE_INT value = INTVAL (XEXP (X, 1));	if (value == 1)	return COSTS_N_INSNS (ix86_cost->add) + rtx_cost(XEXP (X, 0), OUTER_CODE);	if (value == 2 || value == 3)	return COSTS_N_INSNS (ix86_cost->lea)	+ rtx_cost(XEXP (X, 0), OUTER_CODE);	}	case ROTATE:	case ASHIFTRT:	case LSHIFTRT:	case ROTATERT:	if (GET_MODE (XEXP (X, 0)) == DImode)	{	if (GET_CODE (XEXP (X, 1)) == CONST_INT)	if (INTVAL (XEXP (X, 1)) > 32)	return COSTS_N_INSNS(ix86_cost->shift_const + 2);	else	return COSTS_N_INSNS(ix86_cost->shift_const * 2);	return ((GET_CODE (XEXP (X, 1)) == AND	? COSTS_N_INSNS(ix86_cost->shift_var * 2)	: COSTS_N_INSNS(ix86_cost->shift_var * 6 + 2))	+ rtx_cost(XEXP (X, 0), OUTER_CODE));	}	return COSTS_N_INSNS (GET_CODE (XEXP (X, 1)) == CONST_INT	? ix86_cost->shift_const	: ix86_cost->shift_var)	+ rtx_cost(XEXP (X, 0), OUTER_CODE);	case MULT:	if (GET_CODE (XEXP (X, 1)) == CONST_INT)	{	unsigned HOST_WIDE_INT value = INTVAL (XEXP (X, 1));	int nbits = 0;	if (value == 2)	return COSTS_N_INSNS (ix86_cost->add)	+ rtx_cost(XEXP (X, 0), OUTER_CODE);	if (value == 4 || value == 8)	return COSTS_N_INSNS (ix86_cost->lea)	+ rtx_cost(XEXP (X, 0), OUTER_CODE);	while (value != 0)	{	nbits++;	value >>= 1;	} if (nbits == 1)	return COSTS_N_INSNS (ix86_cost->shift_const)	+ rtx_cost(XEXP (X, 0), OUTER_CODE);	return COSTS_N_INSNS (ix86_cost->mult_init	+ nbits * ix86_cost->mult_bit)	+ rtx_cost(XEXP (X, 0), OUTER_CODE);	}	else	TOPLEVEL_COSTS_N_INSNS (ix86_cost->mult_init	+ 7 * ix86_cost->mult_bit);	case DIV:	case UDIV:	case MOD:	case UMOD:	TOPLEVEL_COSTS_N_INSNS (ix86_cost->divide);	case PLUS:	if (GET_CODE (XEXP (X, 0)) == REG	&& GET_MODE (XEXP (X, 0)) == SImode	&& GET_CODE (XEXP (X, 1)) == PLUS)	return COSTS_N_INSNS (ix86_cost->lea);	case AND:	case IOR:	case XOR:	case MINUS:	if (GET_MODE (X) == DImode)	return COSTS_N_INSNS (ix86_cost->add) * 2	+ (rtx_cost (XEXP (X, 0), OUTER_CODE)	<< (GET_MODE (XEXP (X, 0)) != DImode))	+ (rtx_cost (XEXP (X, 1), OUTER_CODE)	<< (GET_MODE (XEXP (X, 1)) != DImode));	case NEG:	case NOT:	if (GET_MODE (X) == DImode)	TOPLEVEL_COSTS_N_INSNS (ix86_cost->add * 2)	TOPLEVEL_COSTS_N_INSNS (ix86_cost->add)
# 2002 "../config/i386/i386.h"


 













































#define ADDRESS_COST(RTX) ((CONSTANT_P (RTX)	|| (GET_CODE (RTX) == PLUS && CONSTANT_P (XEXP (RTX, 1))	&& REG_P (XEXP (RTX, 0)))) ? 0	: REG_P (RTX) ? 1	: 2)






 










#define REGISTER_MOVE_COST(CLASS1, CLASS2)	(((FLOAT_CLASS_P (CLASS1) && ! FLOAT_CLASS_P (CLASS2))	|| (! FLOAT_CLASS_P (CLASS1) && FLOAT_CLASS_P (CLASS2))) ? 10	: 2)





 







 

 


#define BRANCH_COST i386_branch_cost

 













#define SLOW_BYTE_ACCESS 0

 
#define SLOW_SHORT_ACCESS 0

 










 

 











 

 



 

 





#define NO_FUNCTION_CSE

 



#define NO_RECURSIVE_FUNCTION_CSE

 






#define ADJUST_COST(insn,link,dep_insn,cost)	{	rtx next_inst;	if (GET_CODE (dep_insn) == CALL_INSN)	(cost) = 0;	else if (GET_CODE (dep_insn) == INSN	&& GET_CODE (PATTERN (dep_insn)) == SET	&& GET_CODE (SET_DEST (PATTERN (dep_insn))) == REG	&& GET_CODE (insn) == INSN	&& GET_CODE (PATTERN (insn)) == SET	&& !reg_overlap_mentioned_p (SET_DEST (PATTERN (dep_insn)),	SET_SRC (PATTERN (insn))))	{	(cost) = 0;	}	else if (GET_CODE (insn) == JUMP_INSN)	{	(cost) = 0;	}	if (TARGET_PENTIUM)	{	if (cost !=0 && is_fp_insn (insn) && is_fp_insn (dep_insn)	&& !is_fp_dest (dep_insn))	{	(cost) = 0;	}	if (agi_dependent (insn, dep_insn))	{	(cost) = 3;	}	else if (GET_CODE (insn) == INSN	&& GET_CODE (PATTERN (insn)) == SET	&& SET_DEST (PATTERN (insn)) == cc0_rtx	&& (next_inst = next_nonnote_insn (insn))	&& GET_CODE (next_inst) == JUMP_INSN)	{ (cost) = 0;	}	}	else	if (!is_fp_dest (dep_insn))	{	if(!agi_dependent (insn, dep_insn))	(cost) = 0;	else if (TARGET_486)	(cost) = 2;	}	else	if (is_fp_store (insn) && is_fp_insn (dep_insn)	&& NEXT_INSN (insn) && NEXT_INSN (NEXT_INSN (insn))	&& NEXT_INSN (NEXT_INSN (NEXT_INSN (insn)))	&& (GET_CODE (NEXT_INSN (insn)) == INSN)	&& (GET_CODE (NEXT_INSN (NEXT_INSN (insn))) == JUMP_INSN)	&& (GET_CODE (NEXT_INSN (NEXT_INSN (NEXT_INSN (insn)))) == NOTE) && (NOTE_LINE_NUMBER (NEXT_INSN (NEXT_INSN (NEXT_INSN (insn)))) == NOTE_INSN_LOOP_END))	{	(cost) = 3;	}	}
# 2226 "../config/i386/i386.h"


#define ADJUST_BLOCKAGE(last_insn,insn,blockage)	{	if (is_fp_store (last_insn) && is_fp_insn (insn)	&& NEXT_INSN (last_insn) && NEXT_INSN (NEXT_INSN (last_insn))	&& NEXT_INSN (NEXT_INSN (NEXT_INSN (last_insn)))	&& (GET_CODE (NEXT_INSN (last_insn)) == INSN)	&& (GET_CODE (NEXT_INSN (NEXT_INSN (last_insn))) == JUMP_INSN)	&& (GET_CODE (NEXT_INSN (NEXT_INSN (NEXT_INSN (last_insn)))) == NOTE) && (NOTE_LINE_NUMBER (NEXT_INSN (NEXT_INSN (NEXT_INSN (last_insn)))) == NOTE_INSN_LOOP_END))	{	(blockage) = 3;	}	}
# 2242 "../config/i386/i386.h"


 




#define EXTRA_CC_MODES CCFPEQmode

 
#define EXTRA_CC_NAMES "CCFPEQ"

 





#define SELECT_CC_MODE(OP,X,Y) (GET_MODE_CLASS (GET_MODE (X)) == MODE_FLOAT	&& ((OP) == EQ || (OP) == NE) ? CCFPEQmode : VOIDmode)



 



extern struct rtx_def *(*i386_compare_gen)(), *(*i386_compare_gen_eq)();

 

 


 

#define CC_TEST_AX 020000

 

#define CC_IN_80387 04000

 

#define CC_Z_IN_NOT_C 010000

 

#define CC_FCOMI 040000

 




#define NOTICE_UPDATE_CC(EXP, INSN) notice_update_cc((EXP))


 






#define OUTPUT_JUMP(NORMAL, FLOAT, NO_OV)	{	if (cc_prev_status.flags & CC_IN_80387)	return FLOAT;	if (cc_prev_status.flags & CC_NO_OVERFLOW)	return NO_OV;	return NORMAL;	}








 


 


 





#define HI_REGISTER_NAMES {"ax","dx","cx","bx","si","di","bp","sp", "st","st(1)","st(2)","st(3)","st(4)","st(5)","st(6)","st(7)","" }



#define REGISTER_NAMES HI_REGISTER_NAMES

 

#define ADDITIONAL_REGISTER_NAMES { "eax", 0, "edx", 1, "ecx", 2, "ebx", 3,	"esi", 4, "edi", 5, "ebp", 6, "esp", 7,	"al", 0, "dl", 1, "cl", 2, "bl", 3,	"ah", 0, "dh", 1, "ch", 2, "bh", 3 }





 




 



#define QI_REGISTER_NAMES {"al", "dl", "cl", "bl", "si", "di", "bp", "sp",}


 


#define QI_HIGH_REGISTER_NAMES {"ah", "dh", "ch", "bh", }


 

 
#define DBX_REGISTER_NUMBER(n) ((n) == 0 ? 0 : (n) == 1 ? 2 : (n) == 2 ? 1 : (n) == 3 ? 3 : (n) == 4 ? 6 : (n) == 5 ? 7 : (n) == 6 ? 4 : (n) == 7 ? 5 : (n) + 4)
# 2372 "../config/i386/i386.h"

 
#define INCOMING_RETURN_ADDR_RTX gen_rtx (MEM, VOIDmode, gen_rtx (REG, VOIDmode, STACK_POINTER_REGNUM))


 
#define RETURN_ADDR_RTX(COUNT, FRAME)	((COUNT) == 0	? gen_rtx (MEM, Pmode, gen_rtx (PLUS, Pmode, arg_pointer_rtx, GEN_INT(-4))) : gen_rtx (MEM, Pmode, gen_rtx (PLUS, Pmode, (FRAME), GEN_INT(4))))




 
#define DWARF_FRAME_RETURN_COLUMN 	8

 
#define INCOMING_FRAME_SP_OFFSET 4

 


#define ASM_OUTPUT_LABEL(FILE,NAME)	(assemble_name (FILE, NAME), fputs (":\n", FILE))


 

#define ASM_OUTPUT_DOUBLE(FILE,VALUE)	do { long l[2];	REAL_VALUE_TO_TARGET_DOUBLE (VALUE, l);	if (sizeof (int) == sizeof (long))	fprintf (FILE, "%s 0x%x,0x%x\n", ASM_LONG, l[0], l[1]);	else	fprintf (FILE, "%s 0x%lx,0x%lx\n", ASM_LONG, l[0], l[1]);	} while (0)








 

#undef ASM_OUTPUT_LONG_DOUBLE
#define ASM_OUTPUT_LONG_DOUBLE(FILE,VALUE) do { long l[3];	REAL_VALUE_TO_TARGET_LONG_DOUBLE (VALUE, l);	if (sizeof (int) == sizeof (long))	fprintf (FILE, "%s 0x%x,0x%x,0x%x\n", ASM_LONG, l[0], l[1], l[2]); else	fprintf (FILE, "%s 0x%lx,0x%lx,0x%lx\n", ASM_LONG, l[0], l[1], l[2]); } while (0)








 

#define ASM_OUTPUT_FLOAT(FILE,VALUE)	do { long l;	REAL_VALUE_TO_TARGET_SINGLE (VALUE, l);	if (sizeof (int) == sizeof (long))	fprintf ((FILE), "%s 0x%x\n", ASM_LONG, l);	else	fprintf ((FILE), "%s 0x%lx\n", ASM_LONG, l);	} while (0)








 



#define ASM_FORMAT_PRIVATE_NAME(OUTPUT, NAME, LABELNO)	( (OUTPUT) = (char *) alloca (strlen ((NAME)) + 10),	sprintf ((OUTPUT), "%s.%d", (NAME), (LABELNO)))





 

#define ASM_OUTPUT_INT(FILE,VALUE) ( fprintf (FILE, "%s ", ASM_LONG),	output_addr_const (FILE,(VALUE)),	putc('\n',FILE))




 
 

#define ASM_OUTPUT_SHORT(FILE,VALUE) ( fprintf (FILE, "%s ", ASM_SHORT),	output_addr_const (FILE,(VALUE)),	putc('\n',FILE))




 









#define ASM_OUTPUT_CHAR(FILE,VALUE) ( fprintf (FILE, "%s ", ASM_BYTE_OP),	output_addr_const (FILE, (VALUE)),	putc ('\n', FILE))




 

#define ASM_OUTPUT_BYTE(FILE,VALUE) fprintf ((FILE), "%s 0x%x\n", ASM_BYTE_OP, (VALUE))


 


#define ASM_OUTPUT_REG_PUSH(FILE,REGNO) fprintf (FILE, "\tpushl %%e%s\n", reg_names[REGNO])


 


#define ASM_OUTPUT_REG_POP(FILE,REGNO) fprintf (FILE, "\tpopl %%e%s\n", reg_names[REGNO])


 


#define ASM_OUTPUT_ADDR_VEC_ELT(FILE, VALUE) fprintf (FILE, "%s %s%d\n", ASM_LONG, LPREFIX, VALUE)


 




#define ASM_OUTPUT_ADDR_DIFF_ELT(FILE, VALUE, REL) fprintf (FILE, "\t.word %s%d-%s%d\n",LPREFIX, VALUE,LPREFIX, REL)


 


#define ASM_OPEN_PAREN ""
#define ASM_CLOSE_PAREN ""

 
#define TARGET_BELL 007
#define TARGET_BS 010
#define TARGET_TAB 011
#define TARGET_NEWLINE 012
#define TARGET_VT 013
#define TARGET_FF 014
#define TARGET_CR 015

 














#define PRINT_OPERAND_PUNCT_VALID_P(CODE)	((CODE) == '*')


 






extern char *hi_reg_name[];
extern char *qi_reg_name[];
extern char *qi_high_reg_name[];

#define PRINT_REG(X, CODE, FILE) do { if (REGNO (X) == ARG_POINTER_REGNUM)	abort ();	fprintf (FILE, "%s", RP);	switch ((CODE == 'w' ? 2 : CODE == 'b' ? 1	: CODE == 'k' ? 4	: CODE == 'y' ? 3	: CODE == 'h' ? 0	: GET_MODE_SIZE (GET_MODE (X))))	{	case 3:	if (STACK_TOP_P (X))	{	fputs ("st(0)", FILE);	break;	}	case 4:	case 8:	case 12:	if (! FP_REG_P (X)) fputs ("e", FILE);	case 2:	fputs (hi_reg_name[REGNO (X)], FILE);	break;	case 1:	fputs (qi_reg_name[REGNO (X)], FILE);	break;	case 0:	fputs (qi_high_reg_name[REGNO (X)], FILE);	break;	}	} while (0)
# 2576 "../config/i386/i386.h"

#define PRINT_OPERAND(FILE, X, CODE) print_operand (FILE, X, CODE)


#define PRINT_OPERAND_ADDRESS(FILE, ADDR) print_operand_address (FILE, ADDR)


 




#define DEBUG_PRINT_REG(X, CODE, FILE) do { static char *hi_name[] = HI_REGISTER_NAMES;	static char *qi_name[] = QI_REGISTER_NAMES;	fprintf (FILE, "%d %s", REGNO (X), RP);	if (REGNO (X) == ARG_POINTER_REGNUM)	{ fputs ("argp", FILE); break; }	if (STACK_TOP_P (X))	{ fputs ("st(0)", FILE); break; }	if (FP_REG_P (X))	{ fputs (hi_name[REGNO(X)], FILE); break; }	switch (GET_MODE_SIZE (GET_MODE (X)))	{	default:	fputs ("e", FILE);	case 2:	fputs (hi_name[REGNO (X)], FILE);	break;	case 1:	fputs (qi_name[REGNO (X)], FILE);	break;	}	} while (0)
# 2610 "../config/i386/i386.h"

 
#define PRINT_IMMED_PREFIX(FILE)  fputs (IP, (FILE))
#define PRINT_OFFSET_PREFIX(FILE)  fputs (IP, (FILE))

 



#define FLOAT_VALUE_TYPE float
#define INTIFY(FLOATVAL) FLOATVAL

 

 




 


#define ASM_OPERAND_LETTER '#'
#define RET return ""
#define AT_SP(mode) (gen_rtx (MEM, (mode), stack_pointer_rtx))

 
#define IX86_EXPAND_BINARY_OPERATOR(OP, MODE, OPERANDS)	do {	if (!ix86_expand_binary_operator (OP, MODE, OPERANDS))	FAIL;	} while (0)





#define IX86_EXPAND_UNARY_OPERATOR(OP, MODE, OPERANDS)	do {	if (!ix86_expand_unary_operator (OP, MODE, OPERANDS,))	FAIL;	} while (0)






 
extern void override_options ();
extern void order_regs_for_local_alloc ();
extern char *output_strlen_unroll ();
extern struct rtx_def *i386_sext16_if_const ();
extern int i386_aligned_p ();
extern int i386_cc_probably_useless_p ();
extern int i386_valid_decl_attribute_p ();
extern int i386_valid_type_attribute_p ();
extern int i386_return_pops_args ();
extern int i386_comp_type_attributes ();
extern void init_cumulative_args ();
extern void function_arg_advance ();
extern struct rtx_def *function_arg ();
extern int function_arg_partial_nregs ();
extern char *output_strlen_unroll ();
extern void output_op_from_reg ();
extern void output_to_reg ();
extern char *singlemove_string ();
extern char *output_move_double ();
extern char *output_move_memory ();
extern char *output_move_pushmem ();
extern int standard_80387_constant_p ();
extern char *output_move_const_single ();
extern int symbolic_operand ();
extern int call_insn_operand ();
extern int expander_call_insn_operand ();
extern int symbolic_reference_mentioned_p ();
extern int ix86_expand_binary_operator ();
extern int ix86_binary_operator_ok ();
extern int ix86_expand_unary_operator ();
extern int ix86_unary_operator_ok ();
extern void emit_pic_move ();
extern void function_prologue ();
extern int simple_386_epilogue ();
extern void function_epilogue ();
extern int legitimate_address_p ();
extern struct rtx_def *legitimize_pic_address ();
extern struct rtx_def *legitimize_address ();
extern void print_operand ();
extern void print_operand_address ();
extern void notice_update_cc ();
extern void split_di ();
extern int binary_387_op ();
extern int shift_op ();
extern int VOIDmode_compare_op ();
extern char *output_387_binary_op ();
extern char *output_fix_trunc ();
extern char *output_float_compare ();
extern char *output_fp_cc0_set ();
extern void save_386_machine_status ();
extern void restore_386_machine_status ();
extern void clear_386_stack_locals ();
extern struct rtx_def *assign_386_stack_local ();
extern int is_mul ();
extern int is_div ();
extern int last_to_set_cc ();
extern int doesnt_set_condition_code ();
extern int sets_condition_code ();
extern int str_immediate_operand ();
extern int is_fp_insn ();
extern int is_fp_dest ();
extern int is_fp_store ();
extern int agi_dependent ();
extern int reg_mentioned_in_mem ();






 
extern char *ix86_cpu_string;			 
extern char *ix86_arch_string;			 
extern char *i386_reg_alloc_order;		 
extern char *i386_regparm_string;		 
extern char *i386_align_loops_string;		 
extern char *i386_align_jumps_string;		 
extern char *i386_align_funcs_string;		 
extern char *i386_branch_cost_string;		 
extern int i386_regparm;			 
extern int i386_align_loops;			 
extern int i386_align_jumps;			 
extern int i386_align_funcs;			 
extern int i386_branch_cost;			 
extern char *hi_reg_name[];			 
extern char *qi_reg_name[];			 
extern char *qi_high_reg_name[];		 
extern enum reg_class regclass_map[];		 
extern struct rtx_def *i386_compare_op0;	 
extern struct rtx_def *i386_compare_op1;	 

 
extern int optimize;				 
extern int obey_regdecls;			 

 
extern struct rtx_def *force_operand ();


 




# 28 "../config/i386/linux.h" 2

# 1 "../config/i386/att.h" 1
 



















 
# 1 "../config/i386/unix.h" 1
 



















 



 



 



#define AS2(a,b,c) #a " " #b "," #c
#define AS2C(b,c) " " #b "," #c
#define AS3(a,b,c,d) #a " " #b "," #c "," #d
#define AS1(a,b) #a " " #b







 



#define SHIFT_DOUBLE_OMITS_COUNT 1
#define AS3_SHIFT_DOUBLE(a,b,c,d) (SHIFT_DOUBLE_OMITS_COUNT ? AS2 (a,c,d) : AS3 (a,b,c,d))


 



#define PUT_OP_SIZE(CODE,CH,FILE) putc (CH,(FILE))

 
#define L_SIZE "l"

 
#define RP "%"

 
#define IP "$"

 
#define USE_STAR 1

 
#define PRINT_PTR(X, FILE)

 
#define ADDR_BEG(FILE) putc('(', (FILE))
#define ADDR_END(FILE) putc(')', (FILE))

 
#define PRINT_IREG(FILE,IREG) do	{ fputs (",", (FILE)); PRINT_REG ((IREG), 0, (FILE)); }	while (0)



  
 
#define PRINT_SCALE(FILE,SCALE) if ((SCALE) != 1) fprintf ((FILE), ",%d", (SCALE))


 



#define PRINT_B_I_S(BREG,IREG,SCALE,FILE) { ADDR_BEG (FILE); if (BREG) PRINT_REG ((BREG), 0, (FILE));	if ((IREG) != 0)	{ PRINT_IREG ((FILE), (IREG));	PRINT_SCALE ((FILE), (SCALE)); }	ADDR_END (FILE); }







 

 

#define ASM_COMMENT_START "/"

 


#define ASM_APP_ON "/APP\n"

 


#define ASM_APP_OFF "/NO_APP\n"

 

#define TEXT_SECTION_ASM_OP ".text"

 

#define DATA_SECTION_ASM_OP ".data"

 

#define BSS_SECTION_ASM_OP ".bss"

 


#define ASM_GLOBALIZE_LABEL(FILE,NAME)	(fputs (".globl ", FILE), assemble_name (FILE, NAME), fputs ("\n", FILE))


 



#define TARGET_DEFAULT 0301

 

#define VALUE_REGNO(MODE) (GET_MODE_CLASS (MODE) == MODE_FLOAT	&& TARGET_FLOAT_RETURNS_IN_80387 ? FIRST_FLOAT_REG : 0)



 

#define FUNCTION_VALUE_REGNO_P(N) ((N) == 0 || ((N)== FIRST_FLOAT_REG && TARGET_FLOAT_RETURNS_IN_80387))


 

#define ASM_OUTPUT_MI_THUNK(FILE, THUNK_FNDECL, DELTA, FUNCTION)	do {	tree parm;	if (i386_regparm > 0)	parm = TYPE_ARG_TYPES (TREE_TYPE (function));	else	parm = NULL_TREE;	for (; parm; parm = TREE_CHAIN (parm))	if (TREE_VALUE (parm) == void_type_node)	break;	fprintf (FILE, "\taddl $%d,%s\n", DELTA,	parm ? "%eax"	: aggregate_value_p (TREE_TYPE (TREE_TYPE (FUNCTION))) ? "8(%esp)" : "4(%esp)");	if (flag_pic)	{	rtx xops[2];	xops[0] = pic_offset_table_rtx;	xops[1] = (rtx) gen_label_rtx ();	if (i386_regparm > 2)	abort ();	output_asm_insn ("push%L0 %0", xops);	output_asm_insn (AS1 (call,%P1), xops);	ASM_OUTPUT_INTERNAL_LABEL (FILE, "L", CODE_LABEL_NUMBER (xops[1])); output_asm_insn (AS1 (pop%L0,%0), xops);	output_asm_insn ("addl $_GLOBAL_OFFSET_TABLE_+[.-%P1],%0", xops);	fprintf (FILE, "\tmovl ");	assemble_name	(FILE, IDENTIFIER_POINTER (DECL_ASSEMBLER_NAME (FUNCTION)));	fprintf (FILE, "@GOT(%%ebx),%%ecx\n\tpopl %%ebx\n\tjmp *%%ecx\n"); }	else	{	fprintf (FILE, "\tjmp ");	assemble_name	(FILE, IDENTIFIER_POINTER (DECL_ASSEMBLER_NAME (FUNCTION)));	fprintf (FILE, "\n");	}	} while (0)
# 194 "../config/i386/unix.h"
# 22 "../config/i386/att.h" 2


#define TARGET_VERSION fprintf (stderr, " (80386, ATT syntax)");

 

 
#define LPREFIX ".L"

 

 
#define ASM_SHORT "\t.value"
#define ASM_LONG "\t.long"
#define ASM_DOUBLE "\t.double"

 

#define ASM_OUTPUT_ASCII(FILE, p, size) do	{ int i = 0; while (i < (size))	{ if (i%10 == 0) { if (i!=0) fprintf ((FILE), "\n");	fprintf ((FILE), "%s ", ASM_BYTE_OP); }	else fprintf ((FILE), ",");	fprintf ((FILE), "0x%x", ((p)[i++] & 0377)) ;}	fprintf ((FILE), "\n");	} while (0)
# 50 "../config/i386/att.h"

 
#undef ASM_FILE_START_1
#define ASM_FILE_START_1(FILE) fprintf (FILE, "\t.optim\n")

 



#define ASM_OUTPUT_ALIGN(FILE,LOG)	if ((LOG)!=0) fprintf ((FILE), "\t.align %d\n", 1<<(LOG))


 


#define ASM_OUTPUT_SKIP(FILE,SIZE) fprintf ((FILE), "\t.set .,.+%u\n", (SIZE))


 

#define ASM_NO_SKIP_IN_TEXT 1

 

 




#undef ASM_GENERATE_INTERNAL_LABEL
#define ASM_GENERATE_INTERNAL_LABEL(BUF,PREFIX,NUMBER)	sprintf ((BUF), ".%s%d", (PREFIX), (NUMBER))


 


#undef ASM_OUTPUT_INTERNAL_LABEL
#define ASM_OUTPUT_INTERNAL_LABEL(FILE,PREFIX,NUM)	fprintf (FILE, ".%s%d:\n", PREFIX, NUM)


 

#undef USER_LABEL_PREFIX
#define USER_LABEL_PREFIX ""
# 29 "../config/i386/linux.h" 2

# 1 "../config/linux.h" 1
 





















 
#define NO_IMPLICIT_EXTERN_C

#undef HAVE_ATEXIT
#define HAVE_ATEXIT

 







#undef ASM_APP_ON
#define ASM_APP_ON "#APP\n"

#undef ASM_APP_OFF
#define ASM_APP_OFF "#NO_APP\n"

#define SET_ASM_OP	".set"

 
#undef PREFERRED_DEBUGGING_TYPE
#define PREFERRED_DEBUGGING_TYPE DBX_DEBUG
# 1 "../config/svr4.h" 1
 








































 
#define USING_SVR4_H

 
#define HAVE_ATEXIT

 

 




#define SWITCH_TAKES_ARG(CHAR) (DEFAULT_SWITCH_TAKES_ARG (CHAR) || (CHAR) == 'h' || (CHAR) == 'x' || (CHAR) == 'z')





 


#define WORD_SWITCH_TAKES_ARG(STR)	(DEFAULT_WORD_SWITCH_TAKES_ARG (STR)	&& strcmp (STR, "Tdata") && strcmp (STR, "Ttext")	&& strcmp (STR, "Tbss"))




 



#undef CPP_PREDEFINES

 















#undef ASM_SPEC
#define ASM_SPEC "%{v:-V} %{Qy:} %{!Qn:-Qy} %{n} %{T} %{Ym,*} %{Yd,*} %{Wa,*:%*}"


 







#undef ASM_FINAL_SPEC
#define ASM_FINAL_SPEC "%|"

 



#undef MD_EXEC_PREFIX
#define MD_EXEC_PREFIX "/usr/ccs/bin/"


 



#undef MD_STARTFILE_PREFIX
#define MD_STARTFILE_PREFIX "/usr/ccs/lib/"


 


#undef	LIB_SPEC
#define LIB_SPEC "%{!shared:%{!symbolic:-lc}}"

 





#undef  ENDFILE_SPEC
#define ENDFILE_SPEC "crtend.o%s %{pg:gcrtn.o%s}%{!pg:crtn.o%s}"

 






















#undef	LINK_SPEC
# 170 "../config/svr4.h"

#define LINK_SPEC "%{h*} %{v:-V} \
		   %{b} %{Wl,*:%*} \
		   %{static:-dn -Bstatic} \
		   %{shared:-G -dy -z text} \
		   %{symbolic:-Bsymbolic -G -dy -z text} \
		   %{G:-G} \
		   %{YP,*} \
		   %{!YP,*:%{p:-Y P,/usr/ccs/lib/libp:/usr/lib/libp:/usr/ccs/lib:/usr/lib} \
		    %{!p:-Y P,/usr/ccs/lib:/usr/lib}} \
		   %{Qy:} %{!Qn:-Qy}"
# 181 "../config/svr4.h"


 











#undef	STARTFILE_SPEC
#define STARTFILE_SPEC "%{!shared: \
			 %{!symbolic: \
			  %{pg:gcrt1.o%s}%{!pg:%{p:mcrt1.o%s}%{!p:crt1.o%s}}}}\
			%{pg:gcrti.o%s}%{!pg:crti.o%s} \
			%{ansi:values-Xc.o%s} \
			%{!ansi: \
			 %{traditional:values-Xt.o%s} \
			 %{!traditional:values-Xa.o%s}} \
 			crtbegin.o%s"
# 205 "../config/svr4.h"

 




#define IDENT_ASM_OP ".ident"

#define ASM_FILE_END(FILE)	do {	fprintf ((FILE), "\t%s\t\"GCC: (GNU) %s\"\n",	IDENT_ASM_OP, version_string);	} while (0)





 

#define SCCS_DIRECTIVE

 

#define ASM_OUTPUT_IDENT(FILE, NAME) fprintf (FILE, "\t%s\t\"%s\"\n", IDENT_ASM_OP, NAME);


 

#define NO_DOLLAR_IN_LABEL

 

#define PCC_BITFIELD_TYPE_MATTERS 1

 

#define TARGET_MEM_FUNCTIONS

 

#define HANDLE_SYSV_PRAGMA

 

#define DWARF_DEBUGGING_INFO

 

#define DWARF2_DEBUGGING_INFO

 








#undef DBX_REGISTER_NUMBER

 


#define DBX_DEBUGGING_INFO

 

#define DBX_USE_BINCL

 





 




#define DBX_BLOCKS_FUNCTION_RELATIVE 1

 





#define ASM_IDENTIFY_GCC(FILE)	do	{	if (write_symbols != DBX_DEBUG)	fputs ("gcc2_compiled.:\n", FILE);	}	while (0)







#define ASM_IDENTIFY_GCC_AFTER_SOURCE(FILE)	do	{	if (write_symbols == DBX_DEBUG)	fputs ("\t.stabs\t\"gcc2_compiled.\", 0x3c, 0, 0, 0\n", FILE);	}	while (0)







 


#define ASM_OUTPUT_SOURCE_LINE(file, line)	do	{	static int sym_lineno = 1;	fprintf (file, ".stabn 68,0,%d,.LM%d-",	line, sym_lineno);	assemble_name (file,	XSTR (XEXP (DECL_RTL (current_function_decl), 0), 0)); fprintf (file, "\n.LM%d:\n", sym_lineno);	sym_lineno += 1;	}	while (0)
# 322 "../config/svr4.h"

 


#define DBX_FUNCTION_FIRST

 



#define DBX_OUTPUT_MAIN_SOURCE_FILE_END(FILE, FILENAME)	do	{	text_section ();	fprintf (FILE,	"\t.stabs \"\",%d,0,0,.Letext\n.Letext:\n", N_SO);	}	while (0)








 


#undef SIZE_TYPE
#define SIZE_TYPE "unsigned int"

#undef PTRDIFF_TYPE
#define PTRDIFF_TYPE "int"

#undef WCHAR_TYPE
#define WCHAR_TYPE "long int"

#undef WCHAR_TYPE_SIZE
#define WCHAR_TYPE_SIZE BITS_PER_WORD

 

 

#undef ASM_BYTE_OP
#define ASM_BYTE_OP	".byte"

#undef SET_ASM_OP
#define SET_ASM_OP	".set"

 






#undef ASM_FILE_START
#define ASM_FILE_START(FILE) output_file_directive ((FILE), main_input_filename)


 


#define SKIP_ASM_OP	".zero"

#undef ASM_OUTPUT_SKIP
#define ASM_OUTPUT_SKIP(FILE,SIZE) fprintf (FILE, "\t%s\t%u\n", SKIP_ASM_OP, (SIZE))


 




#undef USER_LABEL_PREFIX
#define USER_LABEL_PREFIX ""

 





#undef ASM_OUTPUT_INTERNAL_LABEL
#define ASM_OUTPUT_INTERNAL_LABEL(FILE, PREFIX, NUM)	do {	fprintf (FILE, ".%s%d:\n", PREFIX, NUM);	} while (0)




 







#undef ASM_GENERATE_INTERNAL_LABEL
#define ASM_GENERATE_INTERNAL_LABEL(LABEL, PREFIX, NUM)	do {	sprintf (LABEL, "*.%s%d", PREFIX, NUM);	} while (0)




 







#define ALIGN_ASM_OP ".align"


#define ASM_OUTPUT_BEFORE_CASE_LABEL(FILE,PREFIX,NUM,TABLE) ASM_OUTPUT_ALIGN ((FILE), 2);



#undef ASM_OUTPUT_CASE_LABEL
#define ASM_OUTPUT_CASE_LABEL(FILE,PREFIX,NUM,JUMPTABLE)	do {	ASM_OUTPUT_BEFORE_CASE_LABEL (FILE, PREFIX, NUM, JUMPTABLE)	ASM_OUTPUT_INTERNAL_LABEL (FILE, PREFIX, NUM);	} while (0)





 



#define ASM_OUTPUT_EXTERNAL_LIBCALL(FILE, FUN)	ASM_GLOBALIZE_LABEL (FILE, XSTR (FUN, 0))


 




#define COMMON_ASM_OP	".comm"

#undef ASM_OUTPUT_ALIGNED_COMMON
#define ASM_OUTPUT_ALIGNED_COMMON(FILE, NAME, SIZE, ALIGN)	do {	fprintf ((FILE), "\t%s\t", COMMON_ASM_OP);	assemble_name ((FILE), (NAME));	fprintf ((FILE), ",%u,%u\n", (SIZE), (ALIGN) / BITS_PER_UNIT);	} while (0)






 




#define LOCAL_ASM_OP	".local"

#undef ASM_OUTPUT_ALIGNED_LOCAL
#define ASM_OUTPUT_ALIGNED_LOCAL(FILE, NAME, SIZE, ALIGN)	do {	fprintf ((FILE), "\t%s\t", LOCAL_ASM_OP);	assemble_name ((FILE), (NAME));	fprintf ((FILE), "\n");	ASM_OUTPUT_ALIGNED_COMMON (FILE, NAME, SIZE, ALIGN);	} while (0)







 




#define MAX_OFILE_ALIGNMENT (32768*8)

 



#define INT_ASM_OP		".long"

 



#undef ASCII_DATA_ASM_OP
#define ASCII_DATA_ASM_OP	".ascii"

 







#define USE_CONST_SECTION	1

#define CONST_SECTION_ASM_OP	".section\t.rodata"

 














#define CTORS_SECTION_ASM_OP	".section\t.ctors,\"aw\""
#define DTORS_SECTION_ASM_OP	".section\t.dtors,\"aw\""

 





#define INIT_SECTION_ASM_OP	".section\t.init"
#define FINI_SECTION_ASM_OP	".section\t.fini"

 




#undef EXTRA_SECTIONS
#define EXTRA_SECTIONS in_const, in_ctors, in_dtors

 



#undef EXTRA_SECTION_FUNCTIONS
#define EXTRA_SECTION_FUNCTIONS	CONST_SECTION_FUNCTION	CTORS_SECTION_FUNCTION	DTORS_SECTION_FUNCTION




#define READONLY_DATA_SECTION() const_section ()

extern void text_section ();

#define CONST_SECTION_FUNCTION	void	const_section ()	{	if (!USE_CONST_SECTION)	text_section();	else if (in_section != in_const)	{	fprintf (asm_out_file, "%s\n", CONST_SECTION_ASM_OP);	in_section = in_const;	}	}
# 573 "../config/svr4.h"

#define CTORS_SECTION_FUNCTION	void	ctors_section ()	{	if (in_section != in_ctors)	{	fprintf (asm_out_file, "%s\n", CTORS_SECTION_ASM_OP);	in_section = in_ctors;	}	}
# 584 "../config/svr4.h"

#define DTORS_SECTION_FUNCTION	void	dtors_section ()	{	if (in_section != in_dtors)	{	fprintf (asm_out_file, "%s\n", DTORS_SECTION_ASM_OP);	in_section = in_dtors;	}	}
# 595 "../config/svr4.h"

 









#define ASM_OUTPUT_SECTION_NAME(FILE, DECL, NAME, RELOC)	do {	static struct section_info	{	struct section_info *next;	char *name;	enum sect_enum {SECT_RW, SECT_RO, SECT_EXEC} type;	} *sections;	struct section_info *s;	char *mode;	enum sect_enum type;	for (s = sections; s; s = s->next)	if (!strcmp (NAME, s->name))	break;	if (DECL && TREE_CODE (DECL) == FUNCTION_DECL)	type = SECT_EXEC, mode = "ax";	else if (DECL && DECL_READONLY_SECTION (DECL, RELOC))	type = SECT_RO, mode = "a";	else	type = SECT_RW, mode = "aw";	if (s == 0)	{	s = (struct section_info *) xmalloc (sizeof (struct section_info)); s->name = xmalloc ((strlen (NAME) + 1) * sizeof (*NAME));	strcpy (s->name, NAME);	s->type = type;	s->next = sections;	sections = s;	fprintf (FILE, ".section\t%s,\"%s\",@progbits\n", NAME, mode);	}	else	{	if (DECL && s->type != type)	error_with_decl (DECL, "%s causes a section type conflict");	fprintf (FILE, ".section\t%s\n", NAME);	}	} while (0)
# 647 "../config/svr4.h"

#define MAKE_DECL_ONE_ONLY(DECL) (DECL_WEAK (DECL) = 1)
#define UNIQUE_SECTION_P(DECL) (DECL_ONE_ONLY (DECL))
#define UNIQUE_SECTION(DECL,RELOC)	do {	int len;	char *name, *string, *prefix;	name = IDENTIFIER_POINTER (DECL_ASSEMBLER_NAME (DECL));	if (! DECL_ONE_ONLY (DECL))	prefix = ".";	else if (TREE_CODE (DECL) == FUNCTION_DECL)	prefix = ".gnu.linkonce.t.";	else if (DECL_READONLY_SECTION (DECL, RELOC))	prefix = ".gnu.linkonce.r.";	else	prefix = ".gnu.linkonce.d.";	len = strlen (name) + strlen (prefix);	string = alloca (len + 1);	sprintf (string, "%s%s", prefix, name);	DECL_SECTION_NAME (DECL) = build_string (len, string);	} while (0)
# 672 "../config/svr4.h"

 

#define ASM_OUTPUT_CONSTRUCTOR(FILE,NAME)	do {	ctors_section ();	fprintf (FILE, "\t%s\t ", INT_ASM_OP);	assemble_name (FILE, NAME);	fprintf (FILE, "\n");	} while (0)







 

#define ASM_OUTPUT_DESTRUCTOR(FILE,NAME) do {	dtors_section (); fprintf (FILE, "\t%s\t ", INT_ASM_OP);	assemble_name (FILE, NAME); fprintf (FILE, "\n");	} while (0)







 




#define SELECT_SECTION(DECL,RELOC)	{	if (flag_pic && RELOC)	data_section ();	else if (TREE_CODE (DECL) == STRING_CST)	{	if (! flag_writable_strings)	const_section ();	else	data_section ();	}	else if (TREE_CODE (DECL) == VAR_DECL)	{	if (! DECL_READONLY_SECTION (DECL, RELOC))	data_section ();	else	const_section ();	}	else	const_section ();	}
# 719 "../config/svr4.h"

 





#undef SELECT_RTX_SECTION
#define SELECT_RTX_SECTION(MODE,RTX) const_section()

 





#define TYPE_ASM_OP	".type"
#define SIZE_ASM_OP	".size"

 

#define ASM_WEAKEN_LABEL(FILE,NAME) do { fputs ("\t.weak\t", FILE); assemble_name (FILE, NAME); fputc ('\n', FILE); } while (0)



 





#define TYPE_OPERAND_FMT	"@%s"

 




#define ASM_DECLARE_RESULT(FILE, RESULT)


 




 



#define ASM_DECLARE_FUNCTION_NAME(FILE, NAME, DECL)	do {	fprintf (FILE, "\t%s\t ", TYPE_ASM_OP);	assemble_name (FILE, NAME);	putc (',', FILE);	fprintf (FILE, TYPE_OPERAND_FMT, "function");	putc ('\n', FILE);	ASM_DECLARE_RESULT (FILE, DECL_RESULT (DECL));	ASM_OUTPUT_LABEL(FILE, NAME);	} while (0)
# 779 "../config/svr4.h"

 

#define ASM_DECLARE_OBJECT_NAME(FILE, NAME, DECL)	do {	fprintf (FILE, "\t%s\t ", TYPE_ASM_OP);	assemble_name (FILE, NAME);	putc (',', FILE);	fprintf (FILE, TYPE_OPERAND_FMT, "object");	putc ('\n', FILE);	size_directive_output = 0;	if (!flag_inhibit_size_directive && DECL_SIZE (DECL))	{	size_directive_output = 1;	fprintf (FILE, "\t%s\t ", SIZE_ASM_OP);	assemble_name (FILE, NAME);	fprintf (FILE, ",%d\n",  int_size_in_bytes (TREE_TYPE (DECL)));	}	ASM_OUTPUT_LABEL(FILE, NAME);	} while (0)
# 799 "../config/svr4.h"

 





#define ASM_FINISH_DECLARE_OBJECT(FILE, DECL, TOP_LEVEL, AT_END)	do {	char *name = XSTR (XEXP (DECL_RTL (DECL), 0), 0);	if (!flag_inhibit_size_directive && DECL_SIZE (DECL)	&& ! AT_END && TOP_LEVEL	&& DECL_INITIAL (DECL) == error_mark_node	&& !size_directive_output)	{	size_directive_output = 1;	fprintf (FILE, "\t%s\t ", SIZE_ASM_OP);	assemble_name (FILE, name);	fprintf (FILE, ",%d\n",  int_size_in_bytes (TREE_TYPE (DECL))); }	} while (0)
# 820 "../config/svr4.h"

 

#define ASM_DECLARE_FUNCTION_SIZE(FILE, FNAME, DECL)	do {	if (!flag_inhibit_size_directive)	{	char label[256];	static int labelno;	labelno++;	ASM_GENERATE_INTERNAL_LABEL (label, "Lfe", labelno);	ASM_OUTPUT_INTERNAL_LABEL (FILE, "Lfe", labelno);	fprintf (FILE, "\t%s\t ", SIZE_ASM_OP);	assemble_name (FILE, (FNAME));	fprintf (FILE, ",");	assemble_name (FILE, label);	fprintf (FILE, "-");	assemble_name (FILE, (FNAME));	putc ('\n', FILE);	}	} while (0)
# 841 "../config/svr4.h"

 













#define ESCAPES "\1\1\1\1\1\1\1\1btn\1fr\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\
\0\0\"\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\
\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\\\0\0\0\
\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\1\
\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\
\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\
\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\
\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1\1"
# 865 "../config/svr4.h"

 











#define STRING_LIMIT	((unsigned) 256)

#define STRING_ASM_OP	".string"

 






#define ASM_OUTPUT_LIMITED_STRING(FILE, STR)	do	{	register unsigned char *_limited_str = (unsigned char *) (STR);	register unsigned ch;	fprintf ((FILE), "\t%s\t\"", STRING_ASM_OP);	for (; ch = *_limited_str; _limited_str++)	{	register int escape;	switch (escape = ESCAPES[ch])	{	case 0:	putc (ch, (FILE));	break;	case 1:	fprintf ((FILE), "\\%03o", ch);	break;	default:	putc ('\\', (FILE));	putc (escape, (FILE));	break;	}	}	fprintf ((FILE), "\"\n");	}	while (0)
# 915 "../config/svr4.h"

 






#undef ASM_OUTPUT_ASCII
#define ASM_OUTPUT_ASCII(FILE, STR, LENGTH)	do	{	register unsigned char *_ascii_bytes = (unsigned char *) (STR);	register unsigned char *limit = _ascii_bytes + (LENGTH);	register unsigned bytes_in_chunk = 0;	for (; _ascii_bytes < limit; _ascii_bytes++)	{	register unsigned char *p;	if (bytes_in_chunk >= 60)	{	fprintf ((FILE), "\"\n");	bytes_in_chunk = 0;	}	for (p = _ascii_bytes; p < limit && *p != '\0'; p++)	continue;	if (p < limit && (p - _ascii_bytes) <= STRING_LIMIT)	{	if (bytes_in_chunk > 0)	{	fprintf ((FILE), "\"\n");	bytes_in_chunk = 0;	}	ASM_OUTPUT_LIMITED_STRING ((FILE), _ascii_bytes);	_ascii_bytes = p;	}	else	{	register int escape;	register unsigned ch;	if (bytes_in_chunk == 0)	fprintf ((FILE), "\t%s\t\"", ASCII_DATA_ASM_OP);	switch (escape = ESCAPES[ch = *_ascii_bytes])	{	case 0:	putc (ch, (FILE));	bytes_in_chunk++;	break;	case 1:	fprintf ((FILE), "\\%03o", ch);	bytes_in_chunk += 4;	break;	default:	putc ('\\', (FILE));	putc (escape, (FILE));	bytes_in_chunk += 2;	break;	}	}	}	if (bytes_in_chunk > 0)	fprintf ((FILE), "\"\n");	}	while (0)
# 978 "../config/svr4.h"

 
#define OBJECT_FORMAT_ELF
# 48 "../config/linux.h" 2


#undef MD_EXEC_PREFIX
#undef MD_STARTFILE_PREFIX

 
 
#undef ASM_FILE_START
#define ASM_FILE_START(FILE)	do {	output_file_directive (FILE, main_input_filename);	fprintf (FILE, "\t.version\t\"01.01\"\n");	} while (0)





 



   
#undef	STARTFILE_SPEC
#define STARTFILE_SPEC "%{!shared: \
     %{pg:gcrt1.o%s} %{!pg:%{p:gcrt1.o%s} \
		       %{!p:%{profile:gcrt1.o%s} \
			 %{!profile:crt1.o%s}}}} \
   crti.o%s %{!shared:crtbegin.o%s} %{shared:crtbeginS.o%s}"






 





#undef	ENDFILE_SPEC
#define ENDFILE_SPEC "%{!shared:crtend.o%s} %{shared:crtendS.o%s} crtn.o%s"


 
#undef  CC1_SPEC
#define CC1_SPEC "%{profile:-p}"


#undef DEFAULT_VTABLE_THUNKS
#define DEFAULT_VTABLE_THUNKS 1


#undef	LIB_SPEC
 








#define LIB_SPEC "%{shared: -lc} \
   %{!shared: %{mieee-fp:-lieee} %{pthread:-lpthread} \
	%{profile:-lc_p} %{!profile: -lc}}"










# 30 "../config/i386/linux.h" 2


#undef TARGET_VERSION
#define TARGET_VERSION fprintf (stderr, " (i386 GNU/Linux with ELF)");

 

#undef DEFAULT_PCC_STRUCT_RETURN
#define DEFAULT_PCC_STRUCT_RETURN 1

 


#undef ASM_OUTPUT_ADDR_DIFF_ELT
#define ASM_OUTPUT_ADDR_DIFF_ELT(FILE, VALUE, REL) fprintf (FILE, "\t.long _GLOBAL_OFFSET_TABLE_+[.-%s%d]\n", LPREFIX, VALUE)


 

#define JUMP_TABLES_IN_TEXT_SECTION

 
 





















































#undef DBX_REGISTER_NUMBER
#define DBX_REGISTER_NUMBER(n) ((n) == 0 ? 0 : (n) == 1 ? 2 : (n) == 2 ? 1 : (n) == 3 ? 3 : (n) == 4 ? 6 : (n) == 5 ? 7 : (n) == 6 ? 5 : (n) == 7 ? 4 : ((n) >= FIRST_STACK_REG && (n) <= LAST_STACK_REG) ? (n)+3 : (-1))
# 118 "../config/i386/linux.h"

 


#undef FUNCTION_PROFILER
#define FUNCTION_PROFILER(FILE, LABELNO) {	if (flag_pic)	{	fprintf (FILE, "\tleal %sP%d@GOTOFF(%%ebx),%%edx\n",	LPREFIX, (LABELNO));	fprintf (FILE, "\tcall *mcount@GOT(%%ebx)\n");	}	else	{	fprintf (FILE, "\tmovl $%sP%d,%%edx\n", LPREFIX, (LABELNO));	fprintf (FILE, "\tcall mcount\n");	}	}
# 137 "../config/i386/linux.h"

#undef SIZE_TYPE
#define SIZE_TYPE "unsigned int"
 
#undef PTRDIFF_TYPE
#define PTRDIFF_TYPE "int"
  
#undef WCHAR_TYPE
#define WCHAR_TYPE "long int"
   
#undef WCHAR_TYPE_SIZE
#define WCHAR_TYPE_SIZE BITS_PER_WORD
    
#undef CPP_PREDEFINES
#define CPP_PREDEFINES "-D__ELF__ -Dunix -Dlinux -Asystem(posix)"

#undef CPP_SPEC



#define CPP_SPEC "%(cpp_cpu) %[cpp_cpu] %{fPIC:-D__PIC__ -D__pic__} %{fpic:-D__PIC__ -D__pic__} %{posix:-D_POSIX_SOURCE} %{pthread:-D_REENTRANT}"


#undef CC1_SPEC
#define CC1_SPEC "%(cc1_cpu) %{profile:-p}"

 













 

#undef	LINK_SPEC
# 198 "../config/i386/linux.h"

#define LINK_SPEC "-m elf_i386 %{shared:-shared} \
  %{!shared: \
    %{!ibcs: \
      %{!static: \
	%{rdynamic:-export-dynamic} \
	%{!dynamic-linker:-dynamic-linker /lib/ld-linux.so.2}} \
	%{static:-static}}}"








 
# 1 "../config/i386/perform.h" 1
 



















 

 



 


#define perform_udivsi3(arg0,arg1)	{	register int dx asm("dx");	register int ax asm("ax");	dx = 0;	ax = arg0;	asm ("divl %3" : "=a" (ax), "=d" (dx) : "a" (ax), "g" (arg1), "d" (dx)); return ax;	}
# 40 "../config/i386/perform.h"

#define perform_divsi3(arg0,arg1)	{	register int dx asm("dx");	register int ax asm("ax");	register int cx asm("cx");	ax = arg0;	cx = arg1;	asm ("cltd\n\tidivl %3" : "=a" (ax), "=&d" (dx) : "a" (ax), "c" (cx)); return ax;	}
# 52 "../config/i386/perform.h"

#define perform_umodsi3(arg0,arg1)	{	register int dx asm("dx");	register int ax asm("ax");	dx = 0;	ax = arg0;	asm ("divl %3" : "=a" (ax), "=d" (dx) : "a" (ax), "g" (arg1), "d" (dx)); return dx;	}
# 63 "../config/i386/perform.h"

#define perform_modsi3(arg0,arg1)	{	register int dx asm("dx");	register int ax asm("ax");	register int cx asm("cx");	ax = arg0;	cx = arg1;	asm ("cltd\n\tidivl %3" : "=a" (ax), "=&d" (dx) : "a" (ax), "c" (cx)); return dx;	}
# 75 "../config/i386/perform.h"

#define perform_fixdfsi(arg0)	{	auto unsigned short ostatus;	auto unsigned short nstatus;	auto int ret;	auto double tmp;	&ostatus;	&nstatus;	&ret;	&tmp;	asm volatile ("fnstcw %0" : "=m" (ostatus));	nstatus = ostatus | 0x0c00;	asm volatile ("fldcw %0" :   : "m" (nstatus));	tmp = arg0;	asm volatile ("fldl %0" :   : "m" (tmp));	asm volatile ("fistpl %0" : "=m" (ret));	asm volatile ("fldcw %0" :   : "m" (ostatus));	return ret;	}
# 98 "../config/i386/perform.h"

# 209 "../config/i386/linux.h" 2


 




#define ASM_OUTPUT_ALIGNED_BSS(FILE, DECL, NAME, SIZE, ALIGN) asm_output_aligned_bss (FILE, DECL, NAME, SIZE, ALIGN)

# 2 "../tm.h" 2

# 43 "../config/i386/xm-i386.h" 2

# 22 "../config/i386/xm-linux.h" 2

# 1 "../config/xm-linux.h" 1
 




















#undef  HAVE_ATEXIT
#define HAVE_ATEXIT

#undef  POSIX
#define POSIX

 

#define NO_STAB_H

#undef BSTRING
#define BSTRING
# 23 "../config/i386/xm-linux.h" 2


# 2 "../config.h" 2

