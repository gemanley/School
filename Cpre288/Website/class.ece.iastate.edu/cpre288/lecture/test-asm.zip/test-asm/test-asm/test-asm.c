/*
 * test_asm.c
 *
 * Created: 11/8/2011 5:25:21 PM
 *  Author: zzhang
 */ 

#include <avr/io.h>

// functions in assembly
extern void hello_world();
extern void test_sreg();
extern int add3(int a, int b, int c);

int m, n;

// char hello_world_msg[] = "Hello, World!";

int main(void)
{	
//	hello_world();
	
	test_sreg();
	
	int m = add3(0x1000, 0x2000, 0x3000);
	
    while(1)
    {
        //TODO:: Please write your application code 
    }
}